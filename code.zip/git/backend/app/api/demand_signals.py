"""
Demand Signals API routes
Provides endpoints for managing live demand signals separately from
the main demand-sensing forecast/alert flow.
"""

from flask import Blueprint, request, jsonify
import logging

logger = logging.getLogger(__name__)

demand_signals_bp = Blueprint('demand_signals', __name__)


@demand_signals_bp.route('/sources', methods=['GET'])
def list_signal_sources():
    """List all registered signal sources and their status."""
    try:
        from ..services.demand_sensing.signal_handlers import SignalHandlerRegistry
        handlers = SignalHandlerRegistry.get_all_handlers()

        sources = []
        for name, handler in handlers.items():
            sources.append({
                "name": name,
                "type": handler.__class__.__name__,
                "available": True,
            })

        return jsonify({"success": True, "sources": sources})
    except Exception as e:
        logger.error(f"Error listing signal sources: {e}")
        return jsonify({"success": False, "error": str(e)}), 500


@demand_signals_bp.route('/fetch', methods=['POST'])
def fetch_signals():
    """Fetch signals from specified or all sources."""
    try:
        from ..services.demand_sensing.signal_handlers import SignalHandlerRegistry

        data = request.get_json() or {}
        sku = data.get("sku")
        location = data.get("location")
        sources = data.get("sources")

        signals = SignalHandlerRegistry.fetch_all_signals(
            sku=sku, location=location, sources=sources
        )

        return jsonify({
            "success": True,
            "sources": {k: len(v) for k, v in signals.items()},
            "signals": signals,
        })
    except Exception as e:
        logger.error(f"Error fetching signals: {e}")
        return jsonify({"success": False, "error": str(e)}), 500
