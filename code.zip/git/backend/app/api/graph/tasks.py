"""
Task status query endpoints.
"""

from flask import jsonify

from . import graph_bp
from ...models.task import TaskManager
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@graph_bp.route('/task/<task_id>', methods=['GET'])
@handle_api_error
def get_task(task_id: str):
    """Query task status."""
    task = TaskManager().get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": t('api.taskNotFound', id=task_id)}), 404
    return jsonify({"success": True, "data": task.to_dict()})


@graph_bp.route('/tasks', methods=['GET'])
@handle_api_error
def list_tasks():
    """List all tasks."""
    tasks = TaskManager().list_tasks()
    return jsonify({"success": True, "data": tasks, "count": len(tasks)})
