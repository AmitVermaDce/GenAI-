"""
Graph data retrieval and deletion endpoints.
"""

from flask import jsonify

from . import graph_bp
from ...config import Config
from ...services.graph_builder import GraphBuilderService
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@graph_bp.route('/data/<graph_id>', methods=['GET'])
@handle_api_error
def get_graph_data(graph_id: str):
    """Get graph data (nodes and edges)."""
    builder = GraphBuilderService()
    graph_data = builder.get_graph_data(graph_id)
    return jsonify({"success": True, "data": graph_data})


@graph_bp.route('/delete/<graph_id>', methods=['DELETE'])
@handle_api_error
def delete_graph(graph_id: str):
    """Delete a graph."""
    builder = GraphBuilderService()
    builder.delete_graph(graph_id)
    return jsonify({"success": True, "message": t('api.graphDeleted', id=graph_id)})
