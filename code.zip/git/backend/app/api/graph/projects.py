"""
Project CRUD endpoints.
"""

from flask import request, jsonify

from . import graph_bp
from ...models.project import ProjectManager, ProjectStatus
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@graph_bp.route('/project/<project_id>', methods=['GET'])
@handle_api_error
def get_project(project_id: str):
    """Get project details."""
    project = ProjectManager.get_project(project_id)
    if not project:
        return jsonify({"success": False, "error": t('api.projectNotFound', id=project_id)}), 404
    return jsonify({"success": True, "data": project.to_dict()})


@graph_bp.route('/project/list', methods=['GET'])
@handle_api_error
def list_projects():
    """List all projects."""
    limit = request.args.get('limit', 50, type=int)
    projects = ProjectManager.list_projects(limit=limit)
    return jsonify({
        "success": True,
        "data": [p.to_dict() for p in projects],
        "count": len(projects),
    })


@graph_bp.route('/project/<project_id>', methods=['DELETE'])
@handle_api_error
def delete_project(project_id: str):
    """Delete a project."""
    success = ProjectManager.delete_project(project_id)
    if not success:
        return jsonify({"success": False, "error": t('api.projectDeleteFailed', id=project_id)}), 404
    return jsonify({"success": True, "message": t('api.projectDeleted', id=project_id)})


@graph_bp.route('/project/<project_id>/reset', methods=['POST'])
@handle_api_error
def reset_project(project_id: str):
    """Reset project status for re-building graph."""
    project = ProjectManager.get_project(project_id)
    if not project:
        return jsonify({"success": False, "error": t('api.projectNotFound', id=project_id)}), 404

    if project.ontology:
        project.status = ProjectStatus.ONTOLOGY_GENERATED
    else:
        project.status = ProjectStatus.CREATED

    project.graph_id = None
    project.graph_build_task_id = None
    project.error = None
    ProjectManager.save_project(project)

    return jsonify({
        "success": True,
        "message": t('api.projectReset', id=project_id),
        "data": project.to_dict(),
    })
