"""
Ontology generation endpoint.
"""

import os

from flask import request, jsonify

from . import graph_bp
from ...config import Config
from ...services.ontology_generator import OntologyGenerator
from ...services.text_processor import TextProcessor
from ...utils.file_parser import FileParser
from ...utils.logger import get_logger
from ...utils.locale import t
from ...models.project import ProjectManager, ProjectStatus
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.graph')


def _allowed_file(filename: str) -> bool:
    """Check if file extension is allowed."""
    if not filename or '.' not in filename:
        return False
    ext = os.path.splitext(filename)[1].lower().lstrip('.')
    return ext in Config.ALLOWED_EXTENSIONS


@graph_bp.route('/ontology/generate', methods=['POST'])
@handle_api_error
def generate_ontology():
    """Upload files and generate ontology definition."""
    logger.info("=== Starting ontology generation ===")

    simulation_requirement = request.form.get('simulation_requirement', '')
    project_name = request.form.get('project_name', 'Unnamed Project')
    additional_context = request.form.get('additional_context', '')

    if not simulation_requirement:
        return jsonify({"success": False, "error": t('api.requireSimulationRequirement')}), 400

    uploaded_files = request.files.getlist('files')
    if not uploaded_files or all(not f.filename for f in uploaded_files):
        return jsonify({"success": False, "error": t('api.requireFileUpload')}), 400

    project = ProjectManager.create_project(name=project_name)
    project.simulation_requirement = simulation_requirement

    document_texts = []
    all_text = ""

    for file in uploaded_files:
        if file and file.filename and _allowed_file(file.filename):
            file_info = ProjectManager.save_file_to_project(
                project.project_id, file, file.filename,
            )
            project.files.append({
                "filename": file_info["original_filename"],
                "size": file_info["size"],
            })
            text = FileParser.extract_text(file_info["path"])
            text = TextProcessor.preprocess_text(text)
            document_texts.append(text)
            all_text += f"\n\n=== {file_info['original_filename']} ===\n{text}"

    if not document_texts:
        ProjectManager.delete_project(project.project_id)
        return jsonify({"success": False, "error": t('api.noDocProcessed')}), 400

    project.total_text_length = len(all_text)
    ProjectManager.save_extracted_text(project.project_id, all_text)

    generator = OntologyGenerator()
    ontology = generator.generate(
        document_texts=document_texts,
        simulation_requirement=simulation_requirement,
        additional_context=additional_context or None,
    )

    project.ontology = {
        "entity_types": ontology.get("entity_types", []),
        "edge_types": ontology.get("edge_types", []),
    }
    project.analysis_summary = ontology.get("analysis_summary", "")
    project.status = ProjectStatus.ONTOLOGY_GENERATED
    ProjectManager.save_project(project)

    logger.info(f"=== Ontology generated === project_id: {project.project_id}")

    return jsonify({
        "success": True,
        "data": {
            "project_id": project.project_id,
            "project_name": project.name,
            "ontology": project.ontology,
            "analysis_summary": project.analysis_summary,
            "files": project.files,
            "total_text_length": project.total_text_length,
        },
    })
