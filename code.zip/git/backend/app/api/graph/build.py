"""
Graph build endpoint (async task).
"""

import traceback
import threading

from flask import request, jsonify

from . import graph_bp
from ...config import Config
from ...services.graph_builder import GraphBuilderService
from ...services.text_processor import TextProcessor
from ...utils.logger import get_logger
from ...utils.locale import t, get_locale, set_locale
from ...models.task import TaskManager, TaskStatus
from ...models.project import ProjectManager, ProjectStatus
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.graph')

# ZEP_API_KEY is read from config at import time
ZEP_API_KEY = Config.ZEP_API_KEY


@graph_bp.route('/build', methods=['POST'])
@handle_api_error
def build_graph():
    """Build knowledge graph from project data (async)."""
    logger.info("=== Starting graph build ===")

    if not Config.ZEP_API_KEY:
        return jsonify({"success": False, "error": t('api.zepApiKeyMissing')}), 500

    data = request.get_json() or {}
    project_id = data.get('project_id')
    if not project_id:
        return jsonify({"success": False, "error": t('api.requireProjectId')}), 400

    project = ProjectManager.get_project(project_id)
    if not project:
        return jsonify({"success": False, "error": t('api.projectNotFound', id=project_id)}), 404

    force = data.get('force', False)

    if project.status == ProjectStatus.CREATED:
        return jsonify({"success": False, "error": t('api.ontologyNotGenerated')}), 400

    if project.status == ProjectStatus.GRAPH_BUILDING and not force:
        return jsonify({
            "success": False,
            "error": t('api.graphBuilding'),
            "task_id": project.graph_build_task_id,
        }), 400

    if force and project.status in (
        ProjectStatus.GRAPH_BUILDING, ProjectStatus.FAILED, ProjectStatus.GRAPH_COMPLETED,
    ):
        project.status = ProjectStatus.ONTOLOGY_GENERATED
        project.graph_id = None
        project.graph_build_task_id = None
        project.error = None

    graph_name = data.get('graph_name', project.name or 'Jarvis Graph')
    chunk_size = data.get('chunk_size', project.chunk_size or Config.DEFAULT_CHUNK_SIZE)
    chunk_overlap = data.get('chunk_overlap', project.chunk_overlap or Config.DEFAULT_CHUNK_OVERLAP)

    project.chunk_size = chunk_size
    project.chunk_overlap = chunk_overlap

    text = ProjectManager.get_extracted_text(project_id)
    if not text:
        return jsonify({"success": False, "error": t('api.textNotFound')}), 400

    ontology = project.ontology
    if not ontology:
        return jsonify({"success": False, "error": t('api.ontologyNotFound')}), 400

    task_manager = TaskManager()
    task_id = task_manager.create_task(f"Build graph: {graph_name}")

    project.status = ProjectStatus.GRAPH_BUILDING
    project.graph_build_task_id = task_id
    ProjectManager.save_project(project)

    current_locale = get_locale()

    def build_task():
        set_locale(current_locale)
        build_logger = get_logger('jarvis.build')
        try:
            task_manager.update_task(
                task_id, status=TaskStatus.PROCESSING, message=t('progress.initGraphService'),
            )

            builder = GraphBuilderService(api_key=Config.ZEP_API_KEY)

            task_manager.update_task(task_id, message=t('progress.textChunking'), progress=5)
            chunks = TextProcessor.split_text(text, chunk_size=chunk_size, overlap=chunk_overlap)
            total_chunks = len(chunks)

            task_manager.update_task(task_id, message=t('progress.creatingZepGraph'), progress=10)
            graph_id = builder.create_graph(name=graph_name)
            project.graph_id = graph_id
            ProjectManager.save_project(project)

            task_manager.update_task(task_id, message=t('progress.settingOntology'), progress=15)
            builder.set_ontology(graph_id, ontology)

            def add_progress_callback(msg, progress_ratio):
                task_manager.update_task(
                    task_id, message=msg, progress=15 + int(progress_ratio * 40),
                )

            task_manager.update_task(
                task_id, message=t('progress.addingChunks', count=total_chunks), progress=15,
            )
            episode_uuids = builder.add_text_batches(
                graph_id, chunks, batch_size=3, progress_callback=add_progress_callback,
            )

            task_manager.update_task(task_id, message=t('progress.waitingZepProcess'), progress=55)

            def wait_progress_callback(msg, progress_ratio):
                task_manager.update_task(
                    task_id, message=msg, progress=55 + int(progress_ratio * 35),
                )

            builder._wait_for_episodes(episode_uuids, wait_progress_callback)

            task_manager.update_task(task_id, message=t('progress.fetchingGraphData'), progress=95)
            graph_data = builder.get_graph_data(graph_id)

            project.status = ProjectStatus.GRAPH_COMPLETED
            ProjectManager.save_project(project)

            node_count = graph_data.get("node_count", 0)
            edge_count = graph_data.get("edge_count", 0)

            task_manager.update_task(
                task_id, status=TaskStatus.COMPLETED,
                message=t('progress.graphBuildComplete'), progress=100,
                result={
                    "project_id": project_id,
                    "graph_id": graph_id,
                    "node_count": node_count,
                    "edge_count": edge_count,
                    "chunk_count": total_chunks,
                },
            )

        except Exception as e:
            build_logger.error(f"[{task_id}] Graph build failed: {e}")
            build_logger.debug(traceback.format_exc())
            project.status = ProjectStatus.FAILED
            project.error = str(e)
            ProjectManager.save_project(project)
            task_manager.update_task(
                task_id, status=TaskStatus.FAILED,
                message=t('progress.buildFailed', error=str(e)),
                error=traceback.format_exc(),
            )

    threading.Thread(target=build_task, daemon=True).start()

    return jsonify({
        "success": True,
        "data": {
            "project_id": project_id,
            "task_id": task_id,
            "message": t('api.graphBuildStarted', taskId=task_id),
        },
    })
