"""
Graph API package.

Splits the monolithic graph route module into focused sub-modules.
"""

from flask import Blueprint

graph_bp = Blueprint('graph', __name__)

# Import route modules so their decorators register on the blueprint.
from . import projects   # noqa: E402, F401
from . import ontology   # noqa: E402, F401
from . import build      # noqa: E402, F401
from . import data       # noqa: E402, F401
from . import tasks      # noqa: E402, F401
