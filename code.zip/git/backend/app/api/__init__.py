"""
API route registration module.

Each domain is a sub-package that owns its own Blueprint.
"""

from .graph import graph_bp          # noqa: F401
from .simulation import simulation_bp  # noqa: F401
from .report import report_bp        # noqa: F401
from .scenarios import scenarios_bp  # noqa: F401
from .demand_signals import demand_signals_bp  # noqa: F401

__all__ = [
    "graph_bp",
    "simulation_bp",
    "report_bp",
    "scenarios_bp",
    "demand_signals_bp",
]
