"""
Simulation CRUD and listing endpoints.
"""

from flask import request, jsonify

from . import simulation_bp
from .helpers import logger, _get_report_id_for_simulation
from ...config import Config
from ...services.simulation_manager import SimulationManager, SimulationStatus
from ...services.simulation_runner import SimulationRunner
from ...models.project import ProjectManager
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@simulation_bp.route('/create', methods=['POST'])
@handle_api_error
def create_simulation():
    """Create a new simulation."""
    data = request.get_json() or {}

    project_id = data.get('project_id')
    if not project_id:
        return jsonify({"success": False, "error": t('api.requireProjectId')}), 400

    project = ProjectManager.get_project(project_id)
    if not project:
        return jsonify({"success": False, "error": t('api.projectNotFound', id=project_id)}), 404

    graph_id = data.get('graph_id') or project.graph_id
    if not graph_id:
        return jsonify({"success": False, "error": t('api.graphNotBuilt')}), 400

    manager = SimulationManager()
    state = manager.create_simulation(
        project_id=project_id,
        graph_id=graph_id,
        enable_twitter=data.get('enable_twitter', True),
        enable_reddit=data.get('enable_reddit', True),
    )

    return jsonify({"success": True, "data": state.to_dict()})


@simulation_bp.route('/<simulation_id>', methods=['GET'])
@handle_api_error
def get_simulation(simulation_id: str):
    """Get simulation status."""
    manager = SimulationManager()
    state = manager.get_simulation(simulation_id)

    if not state:
        return jsonify({"success": False, "error": t('api.simulationNotFound', id=simulation_id)}), 404

    result = state.to_dict()
    if state.status == SimulationStatus.READY:
        result["run_instructions"] = manager.get_run_instructions(simulation_id)

    return jsonify({"success": True, "data": result})


@simulation_bp.route('/list', methods=['GET'])
@handle_api_error
def list_simulations():
    """List all simulations, optionally filtered by project_id."""
    project_id = request.args.get('project_id')
    manager = SimulationManager()
    simulations = manager.list_simulations(project_id=project_id)

    return jsonify({
        "success": True,
        "data": [s.to_dict() for s in simulations],
        "count": len(simulations),
    })


@simulation_bp.route('/history', methods=['GET'])
@handle_api_error
def get_simulation_history():
    """Get enriched simulation list with project details."""
    import os

    limit = request.args.get('limit', 20, type=int)
    manager = SimulationManager()
    simulations = manager.list_simulations()[:limit]

    enriched = []
    for sim in simulations:
        sim_dict = sim.to_dict()

        # Simulation config info
        config = manager.get_simulation_config(sim.simulation_id)
        if config:
            sim_dict["simulation_requirement"] = config.get("simulation_requirement", "")
            time_config = config.get("time_config", {})
            sim_dict["total_simulation_hours"] = time_config.get("total_simulation_hours", 0)
            recommended_rounds = int(
                time_config.get("total_simulation_hours", 0) * 60
                / max(time_config.get("minutes_per_round", 60), 1)
            )
        else:
            sim_dict["simulation_requirement"] = ""
            sim_dict["total_simulation_hours"] = 0
            recommended_rounds = 0

        # Run state
        run_state = SimulationRunner.get_run_state(sim.simulation_id)
        if run_state:
            sim_dict["current_round"] = run_state.current_round
            sim_dict["runner_status"] = run_state.runner_status.value
            sim_dict["total_rounds"] = (
                run_state.total_rounds if run_state.total_rounds > 0 else recommended_rounds
            )
        else:
            sim_dict["current_round"] = 0
            sim_dict["runner_status"] = "idle"
            sim_dict["total_rounds"] = recommended_rounds

        # Associated project files
        project = ProjectManager.get_project(sim.project_id)
        if project and hasattr(project, 'files') and project.files:
            sim_dict["files"] = [
                {"filename": f.get("filename", "unknown")} for f in project.files[:3]
            ]
        else:
            sim_dict["files"] = []

        # Report
        sim_dict["report_id"] = _get_report_id_for_simulation(sim.simulation_id)
        sim_dict["version"] = "v1.0.2"

        try:
            sim_dict["created_date"] = sim_dict.get("created_at", "")[:10]
        except Exception:
            sim_dict["created_date"] = ""

        enriched.append(sim_dict)

    return jsonify({"success": True, "data": enriched, "count": len(enriched)})
