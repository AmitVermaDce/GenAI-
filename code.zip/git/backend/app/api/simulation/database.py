"""
Simulation database query endpoints: posts, comments.
"""

import os
import sqlite3

from flask import request, jsonify

from . import simulation_bp
from .helpers import logger
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@simulation_bp.route('/<simulation_id>/posts', methods=['GET'])
@handle_api_error
def get_simulation_posts(simulation_id: str):
    """Get simulation posts from the platform database."""
    platform = request.args.get('platform', 'reddit')
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)

    sim_dir = os.path.join(
        os.path.dirname(__file__), f'../../../uploads/simulations/{simulation_id}',
    )
    db_path = os.path.join(sim_dir, f"{platform}_simulation.db")

    if not os.path.exists(db_path):
        return jsonify({
            "success": True,
            "data": {"platform": platform, "count": 0, "posts": [], "message": t('api.dbNotExist')},
        })

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    try:
        cursor.execute(
            "SELECT * FROM post ORDER BY created_at DESC LIMIT ? OFFSET ?",
            (limit, offset),
        )
        posts = [dict(row) for row in cursor.fetchall()]
        cursor.execute("SELECT COUNT(*) FROM post")
        total = cursor.fetchone()[0]
    except sqlite3.OperationalError:
        posts, total = [], 0
    finally:
        conn.close()

    return jsonify({
        "success": True,
        "data": {"platform": platform, "total": total, "count": len(posts), "posts": posts},
    })


@simulation_bp.route('/<simulation_id>/comments', methods=['GET'])
@handle_api_error
def get_simulation_comments(simulation_id: str):
    """Get simulation comments (Reddit only)."""
    post_id = request.args.get('post_id')
    limit = request.args.get('limit', 50, type=int)
    offset = request.args.get('offset', 0, type=int)

    sim_dir = os.path.join(
        os.path.dirname(__file__), f'../../../uploads/simulations/{simulation_id}',
    )
    db_path = os.path.join(sim_dir, "reddit_simulation.db")

    if not os.path.exists(db_path):
        return jsonify({
            "success": True, "data": {"count": 0, "comments": []},
        })

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    try:
        if post_id:
            cursor.execute(
                "SELECT * FROM comment WHERE post_id = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (post_id, limit, offset),
            )
        else:
            cursor.execute(
                "SELECT * FROM comment ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset),
            )
        comments = [dict(row) for row in cursor.fetchall()]
    except sqlite3.OperationalError:
        comments = []
    finally:
        conn.close()

    return jsonify({
        "success": True, "data": {"count": len(comments), "comments": comments},
    })
