"""
Simulation start / stop / close-env endpoints.
"""

from flask import request, jsonify

from . import simulation_bp
from .helpers import logger, _check_simulation_prepared
from ...config import Config
from ...services.simulation_manager import SimulationManager, SimulationStatus
from ...services.simulation_runner import SimulationRunner
from ...models.project import ProjectManager
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@simulation_bp.route('/start', methods=['POST'])
@handle_api_error
def start_simulation():
    """Start running a simulation."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400

    platform = data.get('platform', 'parallel')
    max_rounds = data.get('max_rounds')
    enable_graph_memory_update = data.get('enable_graph_memory_update', False)
    force = data.get('force', False)

    # Validate max_rounds
    if max_rounds is not None:
        try:
            max_rounds = int(max_rounds)
            if max_rounds <= 0:
                return jsonify({"success": False, "error": t('api.maxRoundsPositive')}), 400
        except (ValueError, TypeError):
            return jsonify({"success": False, "error": t('api.maxRoundsInvalid')}), 400

    if platform not in ('twitter', 'reddit', 'parallel'):
        return jsonify({"success": False, "error": t('api.invalidPlatform', platform=platform)}), 400

    manager = SimulationManager()
    state = manager.get_simulation(simulation_id)
    if not state:
        return jsonify({"success": False, "error": t('api.simulationNotFound', id=simulation_id)}), 404

    force_restarted = False

    if state.status != SimulationStatus.READY:
        is_prepared, _ = _check_simulation_prepared(simulation_id)
        if is_prepared:
            if state.status == SimulationStatus.RUNNING:
                run_state = SimulationRunner.get_run_state(simulation_id)
                if run_state and run_state.runner_status.value == "running":
                    if force:
                        logger.info(f"Force-stopping running simulation {simulation_id}")
                        try:
                            SimulationRunner.stop_simulation(simulation_id)
                        except Exception as e:
                            logger.warning(f"Stop warning: {e}")
                    else:
                        return jsonify({"success": False, "error": t('api.simRunningForceHint')}), 400

            if force:
                cleanup_result = SimulationRunner.cleanup_simulation_logs(simulation_id)
                if not cleanup_result.get("success"):
                    logger.warning(f"Cleanup warnings: {cleanup_result.get('errors')}")
                force_restarted = True

            state.status = SimulationStatus.READY
            manager._save_simulation_state(state)
        else:
            return jsonify({
                "success": False, "error": t('api.simNotReady', status=state.status.value),
            }), 400

    # Graph memory update
    graph_id = None
    if enable_graph_memory_update:
        graph_id = state.graph_id
        if not graph_id:
            project = ProjectManager.get_project(state.project_id)
            if project:
                graph_id = project.graph_id
        if not graph_id:
            return jsonify({"success": False, "error": t('api.graphIdRequiredForMemory')}), 400

    run_state = SimulationRunner.start_simulation(
        simulation_id=simulation_id,
        platform=platform,
        max_rounds=max_rounds,
        enable_graph_memory_update=enable_graph_memory_update,
        graph_id=graph_id,
    )

    state.status = SimulationStatus.RUNNING
    manager._save_simulation_state(state)

    response_data = run_state.to_dict()
    if max_rounds:
        response_data['max_rounds_applied'] = max_rounds
    response_data['graph_memory_update_enabled'] = enable_graph_memory_update
    response_data['force_restarted'] = force_restarted
    if enable_graph_memory_update:
        response_data['graph_id'] = graph_id

    return jsonify({"success": True, "data": response_data})


@simulation_bp.route('/stop', methods=['POST'])
@handle_api_error
def stop_simulation():
    """Stop a simulation."""
    data = request.get_json() or {}
    simulation_id = data.get('simulation_id')
    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400

    run_state = SimulationRunner.stop_simulation(simulation_id)

    manager = SimulationManager()
    state = manager.get_simulation(simulation_id)
    if state:
        state.status = SimulationStatus.PAUSED
        manager._save_simulation_state(state)

    return jsonify({"success": True, "data": run_state.to_dict()})


@simulation_bp.route('/close-env', methods=['POST'])
@handle_api_error
def close_simulation_env():
    """Gracefully close simulation environment."""
    data = request.get_json() or {}
    simulation_id = data.get('simulation_id')
    timeout = data.get('timeout', 30)

    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400

    result = SimulationRunner.close_simulation_env(
        simulation_id=simulation_id, timeout=timeout,
    )

    manager = SimulationManager()
    state = manager.get_simulation(simulation_id)
    if state:
        state.status = SimulationStatus.COMPLETED
        manager._save_simulation_state(state)

    return jsonify({"success": result.get("success", False), "data": result})
