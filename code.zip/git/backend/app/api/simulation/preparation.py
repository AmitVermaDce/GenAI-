"""
Simulation preparation endpoints.
"""

import threading

from flask import request, jsonify

from . import simulation_bp
from .helpers import logger, _check_simulation_prepared
from ...config import Config
from ...services.zep_entity_reader import ZepEntityReader
from ...services.simulation_manager import SimulationManager, SimulationStatus
from ...models.project import ProjectManager
from ...models.task import TaskManager, TaskStatus
from ...utils.locale import t, get_locale, set_locale
from ...middleware.error_handlers import handle_api_error


@simulation_bp.route('/prepare', methods=['POST'])
@handle_api_error
def prepare_simulation():
    """Prepare simulation environment (async task)."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400

    manager = SimulationManager()
    state = manager.get_simulation(simulation_id)
    if not state:
        return jsonify({"success": False, "error": t('api.simulationNotFound', id=simulation_id)}), 404

    force_regenerate = data.get('force_regenerate', False)
    logger.info(f"Processing /prepare: simulation_id={simulation_id}, force={force_regenerate}")

    # Check if already prepared
    if not force_regenerate:
        is_prepared, prepare_info = _check_simulation_prepared(simulation_id)
        if is_prepared:
            logger.info(f"Simulation {simulation_id} already prepared, skipping")
            return jsonify({
                "success": True,
                "data": {
                    "simulation_id": simulation_id,
                    "status": "ready",
                    "message": t('api.alreadyPrepared'),
                    "already_prepared": True,
                    "prepare_info": prepare_info,
                },
            })

    # Fetch project info
    project = ProjectManager.get_project(state.project_id)
    if not project:
        return jsonify({"success": False, "error": t('api.projectNotFound', id=state.project_id)}), 404

    simulation_requirement = project.simulation_requirement or ""
    if not simulation_requirement:
        return jsonify({"success": False, "error": t('api.projectMissingRequirement')}), 400

    document_text = ProjectManager.get_extracted_text(state.project_id) or ""
    entity_types_list = data.get('entity_types')
    use_llm_for_profiles = data.get('use_llm_for_profiles', True)
    parallel_profile_count = data.get('parallel_profile_count', 5)

    # Quick entity count (sync, before async task)
    try:
        reader = ZepEntityReader()
        filtered_preview = reader.filter_defined_entities(
            graph_id=state.graph_id,
            defined_entity_types=entity_types_list,
            enrich_with_edges=False,
        )
        state.entities_count = filtered_preview.filtered_count
        state.entity_types = list(filtered_preview.entity_types)
    except Exception as e:
        logger.warning(f"Sync entity count failed (will retry in task): {e}")

    # Create async task
    task_manager = TaskManager()
    task_id = task_manager.create_task(
        task_type="simulation_prepare",
        metadata={"simulation_id": simulation_id, "project_id": state.project_id},
    )

    state.status = SimulationStatus.PREPARING
    manager._save_simulation_state(state)

    current_locale = get_locale()

    def run_prepare():
        set_locale(current_locale)
        try:
            task_manager.update_task(
                task_id, status=TaskStatus.PROCESSING, progress=0,
                message=t('progress.startPreparingEnv'),
            )

            stage_details = {}

            def progress_callback(stage, progress, message, **kwargs):
                stage_weights = {
                    "reading": (0, 20),
                    "generating_profiles": (20, 70),
                    "generating_config": (70, 90),
                    "copying_scripts": (90, 100),
                }
                start, end = stage_weights.get(stage, (0, 100))
                current_progress = int(start + (end - start) * progress / 100)

                stage_names = {
                    "reading": t('progress.readingGraphEntities'),
                    "generating_profiles": t('progress.generatingProfiles'),
                    "generating_config": t('progress.generatingSimConfig'),
                    "copying_scripts": t('progress.preparingScripts'),
                }

                stage_index = (
                    list(stage_weights.keys()).index(stage) + 1
                    if stage in stage_weights else 1
                )
                total_stages = len(stage_weights)

                stage_details[stage] = {
                    "stage_name": stage_names.get(stage, stage),
                    "stage_progress": progress,
                    "current": kwargs.get("current", 0),
                    "total": kwargs.get("total", 0),
                    "item_name": kwargs.get("item_name", ""),
                }

                detail = stage_details[stage]
                progress_detail_data = {
                    "current_stage": stage,
                    "current_stage_name": stage_names.get(stage, stage),
                    "stage_index": stage_index,
                    "total_stages": total_stages,
                    "stage_progress": progress,
                    "current_item": detail["current"],
                    "total_items": detail["total"],
                    "item_description": message,
                }

                if detail["total"] > 0:
                    detailed_message = (
                        f"[{stage_index}/{total_stages}] {stage_names.get(stage, stage)}: "
                        f"{detail['current']}/{detail['total']} - {message}"
                    )
                else:
                    detailed_message = (
                        f"[{stage_index}/{total_stages}] {stage_names.get(stage, stage)}: {message}"
                    )

                task_manager.update_task(
                    task_id, progress=current_progress,
                    message=detailed_message,
                    progress_detail=progress_detail_data,
                )

            result_state = manager.prepare_simulation(
                simulation_id=simulation_id,
                simulation_requirement=simulation_requirement,
                document_text=document_text,
                defined_entity_types=entity_types_list,
                use_llm_for_profiles=use_llm_for_profiles,
                progress_callback=progress_callback,
                parallel_profile_count=parallel_profile_count,
            )

            task_manager.complete_task(task_id, result=result_state.to_simple_dict())

        except Exception as e:
            logger.error(f"Prepare simulation failed: {e}")
            task_manager.fail_task(task_id, str(e))
            st = manager.get_simulation(simulation_id)
            if st:
                st.status = SimulationStatus.FAILED
                st.error = str(e)
                manager._save_simulation_state(st)

    threading.Thread(target=run_prepare, daemon=True).start()

    return jsonify({
        "success": True,
        "data": {
            "simulation_id": simulation_id,
            "task_id": task_id,
            "status": "preparing",
            "message": t('api.prepareStarted'),
            "already_prepared": False,
            "expected_entities_count": state.entities_count,
            "entity_types": state.entity_types,
        },
    })


@simulation_bp.route('/prepare/status', methods=['POST'])
@handle_api_error
def get_prepare_status():
    """Query preparation task progress."""
    data = request.get_json() or {}
    task_id = data.get('task_id')
    simulation_id = data.get('simulation_id')

    if simulation_id:
        is_prepared, prepare_info = _check_simulation_prepared(simulation_id)
        if is_prepared:
            return jsonify({
                "success": True,
                "data": {
                    "simulation_id": simulation_id,
                    "status": "ready",
                    "progress": 100,
                    "message": t('api.alreadyPrepared'),
                    "already_prepared": True,
                    "prepare_info": prepare_info,
                },
            })

    if not task_id:
        if simulation_id:
            return jsonify({
                "success": True,
                "data": {
                    "simulation_id": simulation_id,
                    "status": "not_started",
                    "progress": 0,
                    "message": t('api.notStartedPrepare'),
                    "already_prepared": False,
                },
            })
        return jsonify({"success": False, "error": t('api.requireTaskOrSimId')}), 400

    task_manager = TaskManager()
    task = task_manager.get_task(task_id)

    if not task:
        if simulation_id:
            is_prepared, prepare_info = _check_simulation_prepared(simulation_id)
            if is_prepared:
                return jsonify({
                    "success": True,
                    "data": {
                        "simulation_id": simulation_id,
                        "task_id": task_id,
                        "status": "ready",
                        "progress": 100,
                        "message": t('api.taskCompletedPrepared'),
                        "already_prepared": True,
                        "prepare_info": prepare_info,
                    },
                })
        return jsonify({"success": False, "error": t('api.taskNotFound', id=task_id)}), 404

    task_dict = task.to_dict()
    task_dict["already_prepared"] = False
    return jsonify({"success": True, "data": task_dict})
