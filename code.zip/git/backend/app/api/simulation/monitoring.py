"""
Real-time simulation monitoring endpoints:
run-status, run-status/detail, actions, timeline, agent-stats, env-status.
"""

from flask import request, jsonify

from . import simulation_bp
from .helpers import logger
from ...services.simulation_runner import SimulationRunner
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@simulation_bp.route('/<simulation_id>/run-status', methods=['GET'])
@handle_api_error
def get_run_status(simulation_id: str):
    """Get real-time simulation run status."""
    run_state = SimulationRunner.get_run_state(simulation_id)

    if not run_state:
        return jsonify({
            "success": True,
            "data": {
                "simulation_id": simulation_id,
                "runner_status": "idle",
                "current_round": 0,
                "total_rounds": 0,
                "progress_percent": 0,
                "twitter_actions_count": 0,
                "reddit_actions_count": 0,
                "total_actions_count": 0,
            },
        })

    return jsonify({"success": True, "data": run_state.to_dict()})


@simulation_bp.route('/<simulation_id>/run-status/detail', methods=['GET'])
@handle_api_error
def get_run_status_detail(simulation_id: str):
    """Get detailed simulation run status with all actions."""
    run_state = SimulationRunner.get_run_state(simulation_id)
    platform_filter = request.args.get('platform')

    if not run_state:
        return jsonify({
            "success": True,
            "data": {
                "simulation_id": simulation_id,
                "runner_status": "idle",
                "all_actions": [],
                "twitter_actions": [],
                "reddit_actions": [],
            },
        })

    all_actions = SimulationRunner.get_all_actions(
        simulation_id=simulation_id, platform=platform_filter,
    )
    twitter_actions = (
        SimulationRunner.get_all_actions(simulation_id=simulation_id, platform="twitter")
        if not platform_filter or platform_filter == "twitter" else []
    )
    reddit_actions = (
        SimulationRunner.get_all_actions(simulation_id=simulation_id, platform="reddit")
        if not platform_filter or platform_filter == "reddit" else []
    )

    current_round = run_state.current_round
    recent_actions = (
        SimulationRunner.get_all_actions(
            simulation_id=simulation_id, platform=platform_filter, round_num=current_round,
        ) if current_round > 0 else []
    )

    result = run_state.to_dict()
    result["all_actions"] = [a.to_dict() for a in all_actions]
    result["twitter_actions"] = [a.to_dict() for a in twitter_actions]
    result["reddit_actions"] = [a.to_dict() for a in reddit_actions]
    result["rounds_count"] = len(run_state.rounds)
    result["recent_actions"] = [a.to_dict() for a in recent_actions]

    return jsonify({"success": True, "data": result})


@simulation_bp.route('/<simulation_id>/actions', methods=['GET'])
@handle_api_error
def get_simulation_actions(simulation_id: str):
    """Get agent actions with pagination and filtering."""
    limit = request.args.get('limit', 100, type=int)
    offset = request.args.get('offset', 0, type=int)
    platform = request.args.get('platform')
    agent_id = request.args.get('agent_id', type=int)
    round_num = request.args.get('round_num', type=int)

    actions = SimulationRunner.get_actions(
        simulation_id=simulation_id,
        limit=limit, offset=offset,
        platform=platform, agent_id=agent_id, round_num=round_num,
    )

    return jsonify({
        "success": True,
        "data": {"count": len(actions), "actions": [a.to_dict() for a in actions]},
    })


@simulation_bp.route('/<simulation_id>/timeline', methods=['GET'])
@handle_api_error
def get_simulation_timeline(simulation_id: str):
    """Get simulation timeline (round-by-round)."""
    start_round = request.args.get('start_round', 0, type=int)
    end_round = request.args.get('end_round', type=int)

    timeline = SimulationRunner.get_timeline(
        simulation_id=simulation_id,
        start_round=start_round, end_round=end_round,
    )

    return jsonify({
        "success": True,
        "data": {"rounds_count": len(timeline), "timeline": timeline},
    })


@simulation_bp.route('/<simulation_id>/agent-stats', methods=['GET'])
@handle_api_error
def get_agent_stats(simulation_id: str):
    """Get per-agent statistics."""
    stats = SimulationRunner.get_agent_stats(simulation_id)
    return jsonify({
        "success": True,
        "data": {"agents_count": len(stats), "stats": stats},
    })


@simulation_bp.route('/env-status', methods=['POST'])
@handle_api_error
def get_env_status():
    """Check if simulation environment is alive."""
    data = request.get_json() or {}
    simulation_id = data.get('simulation_id')
    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400

    env_alive = SimulationRunner.check_env_alive(simulation_id)
    env_status = SimulationRunner.get_env_status_detail(simulation_id)

    return jsonify({
        "success": True,
        "data": {
            "simulation_id": simulation_id,
            "env_alive": env_alive,
            "twitter_available": env_status.get("twitter_available", False),
            "reddit_available": env_status.get("reddit_available", False),
            "message": t('api.envRunning') if env_alive else t('api.envNotRunningShort'),
        },
    })
