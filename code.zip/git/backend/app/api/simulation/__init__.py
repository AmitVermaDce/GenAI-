"""
Simulation API package.

Splits the monolithic simulation route module into focused sub-modules
organised by responsibility.
"""

from flask import Blueprint

simulation_bp = Blueprint('simulation', __name__)

# Import route modules so their decorators register on the blueprint.
from . import crud          # noqa: E402, F401
from . import preparation   # noqa: E402, F401
from . import execution     # noqa: E402, F401
from . import monitoring    # noqa: E402, F401
from . import interview     # noqa: E402, F401
from . import database      # noqa: E402, F401
from . import profiles      # noqa: E402, F401
