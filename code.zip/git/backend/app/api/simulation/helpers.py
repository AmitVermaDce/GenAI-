"""
Shared helpers used across simulation sub-modules.
"""

import os
import json
import logging

from ...config import Config
from ...utils.logger import get_logger
from ...utils.locale import t

logger = get_logger('jarvis.api.simulation')

# Interview prompt prefix — prevents Agent from calling tools instead of replying
INTERVIEW_PROMPT_PREFIX = (
    "persona, all past toward memory and line dynamic , "
    "not calltool directly textreply: "
)


def optimize_interview_prompt(prompt: str) -> str:
    """Add a prefix to interview prompts to prevent tool-calling behaviour."""
    if not prompt:
        return prompt
    if prompt.startswith(INTERVIEW_PROMPT_PREFIX):
        return prompt
    return f"{INTERVIEW_PROMPT_PREFIX}{prompt}"


def _check_simulation_prepared(simulation_id: str) -> tuple:
    """
    Check whether a simulation has been fully prepared.

    Returns:
        (is_prepared: bool, info: dict)
    """
    from datetime import datetime

    simulation_dir = os.path.join(Config.OASIS_SIMULATION_DATA_DIR, simulation_id)

    if not os.path.exists(simulation_dir):
        return False, {"reason": "simulation directory does not exist"}

    required_files = [
        "state.json",
        "simulation_config.json",
        "reddit_profiles.json",
        "twitter_profiles.csv",
    ]

    existing_files = []
    missing_files = []
    for f in required_files:
        if os.path.exists(os.path.join(simulation_dir, f)):
            existing_files.append(f)
        else:
            missing_files.append(f)

    if missing_files:
        return False, {
            "reason": "missing required files",
            "missing_files": missing_files,
            "existing_files": existing_files,
        }

    state_file = os.path.join(simulation_dir, "state.json")
    try:
        with open(state_file, "r", encoding="utf-8") as fh:
            state_data = json.load(fh)

        status = state_data.get("status", "")
        config_generated = state_data.get("config_generated", False)

        logger.debug(
            f"Simulation prepare status: {simulation_id}, "
            f"status={status}, config_generated={config_generated}"
        )

        prepared_statuses = [
            "ready", "preparing", "running", "completed", "stopped", "failed",
        ]

        if status in prepared_statuses and config_generated:
            profiles_file = os.path.join(simulation_dir, "reddit_profiles.json")
            profiles_count = 0
            if os.path.exists(profiles_file):
                with open(profiles_file, "r", encoding="utf-8") as fh:
                    profiles_data = json.load(fh)
                    profiles_count = len(profiles_data) if isinstance(profiles_data, list) else 0

            # Auto-promote "preparing" → "ready"
            if status == "preparing":
                try:
                    state_data["status"] = "ready"
                    state_data["updated_at"] = datetime.now().isoformat()
                    with open(state_file, "w", encoding="utf-8") as fh:
                        json.dump(state_data, fh, ensure_ascii=False, indent=2)
                    logger.info(
                        f"Auto-promoted simulation status: {simulation_id} preparing -> ready"
                    )
                    status = "ready"
                except Exception as e:
                    logger.warning(f"Auto-promote failed: {e}")

            return True, {
                "status": status,
                "entities_count": state_data.get("entities_count", 0),
                "profiles_count": profiles_count,
                "entity_types": state_data.get("entity_types", []),
                "config_generated": config_generated,
                "created_at": state_data.get("created_at"),
                "updated_at": state_data.get("updated_at"),
                "existing_files": existing_files,
            }
        else:
            return False, {
                "reason": (
                    f"status not in prepared list or config_generated is false: "
                    f"status={status}, config_generated={config_generated}"
                ),
                "status": status,
                "config_generated": config_generated,
            }

    except Exception as e:
        return False, {"reason": f"Failed to read state file: {str(e)}"}


def _get_report_id_for_simulation(simulation_id: str) -> str | None:
    """Find the most recent report_id for a given simulation."""
    reports_dir = os.path.join(os.path.dirname(__file__), "../../../uploads/reports")
    if not os.path.exists(reports_dir):
        return None

    matching = []
    try:
        for folder in os.listdir(reports_dir):
            meta_file = os.path.join(reports_dir, folder, "meta.json")
            if not os.path.isfile(meta_file):
                continue
            try:
                with open(meta_file, "r", encoding="utf-8") as fh:
                    meta = json.load(fh)
                if meta.get("simulation_id") == simulation_id:
                    matching.append(meta)
            except Exception:
                continue

        if not matching:
            return None
        matching.sort(key=lambda x: x.get("created_at", ""), reverse=True)
        return matching[0].get("report_id")
    except Exception as e:
        logger.warning(f"Failed to find report for simulation {simulation_id}: {e}")
        return None
