"""
Agent interview endpoints: single, batch, all-agents, and history.
"""

from flask import request, jsonify

from . import simulation_bp
from .helpers import logger, optimize_interview_prompt
from ...services.simulation_runner import SimulationRunner
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@simulation_bp.route('/interview', methods=['POST'])
@handle_api_error
def interview_agent():
    """Interview a single agent."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    agent_id = data.get('agent_id')
    prompt = data.get('prompt')
    platform = data.get('platform')
    timeout = data.get('timeout', 60)

    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400
    if agent_id is None:
        return jsonify({"success": False, "error": t('api.requireAgentId')}), 400
    if not prompt:
        return jsonify({"success": False, "error": t('api.requirePrompt')}), 400
    if platform and platform not in ("twitter", "reddit"):
        return jsonify({"success": False, "error": t('api.invalidInterviewPlatform')}), 400

    if not SimulationRunner.check_env_alive(simulation_id):
        return jsonify({"success": False, "error": t('api.envNotRunning')}), 400

    result = SimulationRunner.interview_agent(
        simulation_id=simulation_id,
        agent_id=agent_id,
        prompt=optimize_interview_prompt(prompt),
        platform=platform,
        timeout=timeout,
    )

    return jsonify({"success": result.get("success", False), "data": result})


@simulation_bp.route('/interview/batch', methods=['POST'])
@handle_api_error
def interview_agents_batch():
    """Batch-interview multiple agents."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    interviews = data.get('interviews')
    platform = data.get('platform')
    timeout = data.get('timeout', 120)

    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400
    if not interviews or not isinstance(interviews, list):
        return jsonify({"success": False, "error": t('api.requireInterviews')}), 400
    if platform and platform not in ("twitter", "reddit"):
        return jsonify({"success": False, "error": t('api.invalidInterviewPlatform')}), 400

    for i, item in enumerate(interviews):
        if 'agent_id' not in item:
            return jsonify({"success": False, "error": t('api.interviewListMissingAgentId', index=i + 1)}), 400
        if 'prompt' not in item:
            return jsonify({"success": False, "error": t('api.interviewListMissingPrompt', index=i + 1)}), 400
        if item.get('platform') and item['platform'] not in ("twitter", "reddit"):
            return jsonify({"success": False, "error": t('api.interviewListInvalidPlatform', index=i + 1)}), 400

    if not SimulationRunner.check_env_alive(simulation_id):
        return jsonify({"success": False, "error": t('api.envNotRunning')}), 400

    optimised = []
    for item in interviews:
        copy = item.copy()
        copy['prompt'] = optimize_interview_prompt(item.get('prompt', ''))
        optimised.append(copy)

    result = SimulationRunner.interview_agents_batch(
        simulation_id=simulation_id,
        interviews=optimised,
        platform=platform,
        timeout=timeout,
    )

    return jsonify({"success": result.get("success", False), "data": result})


@simulation_bp.route('/interview/all', methods=['POST'])
@handle_api_error
def interview_all_agents():
    """Interview all agents with the same prompt."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    prompt = data.get('prompt')
    platform = data.get('platform')
    timeout = data.get('timeout', 180)

    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400
    if not prompt:
        return jsonify({"success": False, "error": t('api.requirePrompt')}), 400
    if platform and platform not in ("twitter", "reddit"):
        return jsonify({"success": False, "error": t('api.invalidInterviewPlatform')}), 400

    if not SimulationRunner.check_env_alive(simulation_id):
        return jsonify({"success": False, "error": t('api.envNotRunning')}), 400

    result = SimulationRunner.interview_all_agents(
        simulation_id=simulation_id,
        prompt=optimize_interview_prompt(prompt),
        platform=platform,
        timeout=timeout,
    )

    return jsonify({"success": result.get("success", False), "data": result})


@simulation_bp.route('/interview/history', methods=['POST'])
@handle_api_error
def get_interview_history():
    """Get interview history."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400

    history = SimulationRunner.get_interview_history(
        simulation_id=simulation_id,
        platform=data.get('platform'),
        agent_id=data.get('agent_id'),
        limit=data.get('limit', 100),
    )

    return jsonify({
        "success": True,
        "data": {"count": len(history), "history": history},
    })
