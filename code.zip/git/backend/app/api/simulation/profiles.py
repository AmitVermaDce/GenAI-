"""
Simulation profile and config endpoints:
profiles, realtime profiles, config, config/realtime, config/download,
generate-profiles, script download.
"""

import os
import json
import csv
from datetime import datetime

from flask import request, jsonify, send_file

from . import simulation_bp
from .helpers import logger
from ...config import Config
from ...services.entity_reader import EntityReader
from ...services.oasis_profile_generator import OasisProfileGenerator
from ...services.simulation_manager import SimulationManager
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error


@simulation_bp.route('/<simulation_id>/profiles', methods=['GET'])
@handle_api_error
def get_simulation_profiles(simulation_id: str):
    """Get simulation agent profiles."""
    platform = request.args.get('platform', 'reddit')
    manager = SimulationManager()
    profiles = manager.get_profiles(simulation_id, platform=platform)

    return jsonify({
        "success": True,
        "data": {"platform": platform, "count": len(profiles), "profiles": profiles},
    })


@simulation_bp.route('/<simulation_id>/profiles/realtime', methods=['GET'])
@handle_api_error
def get_simulation_profiles_realtime(simulation_id: str):
    """Realtime profile reading — works even during generation."""
    platform = request.args.get('platform', 'reddit')
    sim_dir = os.path.join(Config.OASIS_SIMULATION_DATA_DIR, simulation_id)

    if not os.path.exists(sim_dir):
        return jsonify({"success": False, "error": t('api.simulationNotFound', id=simulation_id)}), 404

    if platform == "reddit":
        profiles_file = os.path.join(sim_dir, "reddit_profiles.json")
    else:
        profiles_file = os.path.join(sim_dir, "twitter_profiles.csv")

    profiles = []
    file_modified_at = None
    file_exists = os.path.exists(profiles_file)

    if file_exists:
        file_modified_at = datetime.fromtimestamp(os.stat(profiles_file).st_mtime).isoformat()
        try:
            if platform == "reddit":
                with open(profiles_file, 'r', encoding='utf-8') as fh:
                    profiles = json.load(fh)
            else:
                with open(profiles_file, 'r', encoding='utf-8') as fh:
                    profiles = list(csv.DictReader(fh))
        except Exception as e:
            logger.warning(f"Failed to read profiles (may be writing): {e}")

    is_generating = False
    total_expected = None
    state_file = os.path.join(sim_dir, "state.json")
    if os.path.exists(state_file):
        try:
            with open(state_file, 'r', encoding='utf-8') as fh:
                state_data = json.load(fh)
                is_generating = state_data.get("status") == "preparing"
                total_expected = state_data.get("entities_count")
        except Exception:
            pass

    return jsonify({
        "success": True,
        "data": {
            "simulation_id": simulation_id,
            "platform": platform,
            "count": len(profiles),
            "total_expected": total_expected,
            "is_generating": is_generating,
            "file_exists": file_exists,
            "file_modified_at": file_modified_at,
            "profiles": profiles,
        },
    })


@simulation_bp.route('/<simulation_id>/config/realtime', methods=['GET'])
@handle_api_error
def get_simulation_config_realtime(simulation_id: str):
    """Realtime config reading — works during generation."""
    sim_dir = os.path.join(Config.OASIS_SIMULATION_DATA_DIR, simulation_id)
    if not os.path.exists(sim_dir):
        return jsonify({"success": False, "error": t('api.simulationNotFound', id=simulation_id)}), 404

    config_file = os.path.join(sim_dir, "simulation_config.json")
    file_exists = os.path.exists(config_file)
    config = None
    file_modified_at = None

    if file_exists:
        file_modified_at = datetime.fromtimestamp(os.stat(config_file).st_mtime).isoformat()
        try:
            with open(config_file, 'r', encoding='utf-8') as fh:
                config = json.load(fh)
        except Exception as e:
            logger.warning(f"Failed to read config (may be writing): {e}")

    is_generating = False
    generation_stage = None
    config_generated = False
    state_file = os.path.join(sim_dir, "state.json")
    if os.path.exists(state_file):
        try:
            with open(state_file, 'r', encoding='utf-8') as fh:
                state_data = json.load(fh)
                status = state_data.get("status", "")
                is_generating = status == "preparing"
                config_generated = state_data.get("config_generated", False)
                if is_generating:
                    generation_stage = (
                        "generating_config" if state_data.get("profiles_generated") else "generating_profiles"
                    )
                elif status == "ready":
                    generation_stage = "completed"
        except Exception:
            pass

    response_data = {
        "simulation_id": simulation_id,
        "file_exists": file_exists,
        "file_modified_at": file_modified_at,
        "is_generating": is_generating,
        "generation_stage": generation_stage,
        "config_generated": config_generated,
        "config": config,
    }

    if config:
        response_data["summary"] = {
            "total_agents": len(config.get("agent_configs", [])),
            "simulation_hours": config.get("time_config", {}).get("total_simulation_hours"),
            "initial_posts_count": len(config.get("event_config", {}).get("initial_posts", [])),
            "hot_topics_count": len(config.get("event_config", {}).get("hot_topics", [])),
            "has_twitter_config": "twitter_config" in config,
            "has_reddit_config": "reddit_config" in config,
            "generated_at": config.get("generated_at"),
            "llm_model": config.get("llm_model"),
        }

    return jsonify({"success": True, "data": response_data})


@simulation_bp.route('/<simulation_id>/config', methods=['GET'])
@handle_api_error
def get_simulation_config(simulation_id: str):
    """Get simulation config."""
    manager = SimulationManager()
    config = manager.get_simulation_config(simulation_id)
    if not config:
        return jsonify({"success": False, "error": t('api.configNotFound')}), 404
    return jsonify({"success": True, "data": config})


@simulation_bp.route('/<simulation_id>/config/download', methods=['GET'])
@handle_api_error
def download_simulation_config(simulation_id: str):
    """Download simulation config file."""
    manager = SimulationManager()
    sim_dir = manager._get_simulation_dir(simulation_id)
    config_path = os.path.join(sim_dir, "simulation_config.json")

    if not os.path.exists(config_path):
        return jsonify({"success": False, "error": t('api.configFileNotFound')}), 404

    return send_file(config_path, as_attachment=True, download_name="simulation_config.json")


@simulation_bp.route('/script/<script_name>/download', methods=['GET'])
@handle_api_error
def download_simulation_script(script_name: str):
    """Download a simulation run script."""
    scripts_dir = os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../scripts'))
    allowed_scripts = [
        "run_twitter_simulation.py",
        "run_reddit_simulation.py",
        "run_parallel_simulation.py",
        "action_logger.py",
    ]

    if script_name not in allowed_scripts:
        return jsonify({
            "success": False,
            "error": t('api.unknownScript', name=script_name, allowed=allowed_scripts),
        }), 400

    script_path = os.path.join(scripts_dir, script_name)
    if not os.path.exists(script_path):
        return jsonify({"success": False, "error": t('api.scriptFileNotFound', name=script_name)}), 404

    return send_file(script_path, as_attachment=True, download_name=script_name)


@simulation_bp.route('/generate-profiles', methods=['POST'])
@handle_api_error
def generate_profiles():
    """Generate OASIS agent profiles directly from graph entities."""
    data = request.get_json() or {}

    graph_id = data.get('graph_id')
    if not graph_id:
        return jsonify({"success": False, "error": t('api.requireGraphId')}), 400

    entity_types = data.get('entity_types')
    use_llm = data.get('use_llm', True)
    platform = data.get('platform', 'reddit')

    reader = EntityReader()
    filtered = reader.filter_defined_entities(
        graph_id=graph_id, defined_entity_types=entity_types, enrich_with_edges=True,
    )

    if filtered.filtered_count == 0:
        return jsonify({"success": False, "error": t('api.noMatchingEntities')}), 400

    generator = OasisProfileGenerator()
    profiles = generator.generate_profiles_from_entities(entities=filtered.entities, use_llm=use_llm)

    if platform == "reddit":
        profiles_data = [p.to_reddit_format() for p in profiles]
    elif platform == "twitter":
        profiles_data = [p.to_twitter_format() for p in profiles]
    else:
        profiles_data = [p.to_dict() for p in profiles]

    return jsonify({
        "success": True,
        "data": {
            "platform": platform,
            "entity_types": list(filtered.entity_types),
            "count": len(profiles_data),
            "profiles": profiles_data,
        },
    })
