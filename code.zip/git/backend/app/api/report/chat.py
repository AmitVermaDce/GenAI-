"""
Report Agent chat endpoint.
"""

from flask import request, jsonify

from . import report_bp
from ...services.report_agent import ReportAgent
from ...services.simulation_manager import SimulationManager
from ...models.project import ProjectManager
from ...utils.logger import get_logger
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.report')


@report_bp.route('/chat', methods=['POST'])
@handle_api_error
def chat_with_report_agent():
    """Chat with the Report Agent."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    message = data.get('message')
    chat_history = data.get('chat_history', [])

    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400
    if not message:
        return jsonify({"success": False, "error": t('api.requireMessage')}), 400

    manager = SimulationManager()
    state = manager.get_simulation(simulation_id)
    if not state:
        return jsonify({"success": False, "error": t('api.simulationNotFound', id=simulation_id)}), 404

    project = ProjectManager.get_project(state.project_id)
    if not project:
        return jsonify({"success": False, "error": t('api.projectNotFound', id=state.project_id)}), 404

    graph_id = state.graph_id or project.graph_id
    if not graph_id:
        return jsonify({"success": False, "error": t('api.missingGraphId')}), 400

    agent = ReportAgent(
        graph_id=graph_id,
        simulation_id=simulation_id,
        simulation_requirement=project.simulation_requirement or "",
    )

    result = agent.chat(message=message, chat_history=chat_history)
    return jsonify({"success": True, "data": result})
