"""
Report agent log and console log endpoints.
"""

from flask import request, jsonify

from . import report_bp
from ...services.report_agent import ReportManager
from ...utils.logger import get_logger
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.report')


@report_bp.route('/<report_id>/agent-log', methods=['GET'])
@handle_api_error
def get_agent_log(report_id: str):
    """Get detailed Report Agent execution log."""
    from_line = request.args.get('from_line', 0, type=int)
    log_data = ReportManager.get_agent_log(report_id, from_line=from_line)
    return jsonify({"success": True, "data": log_data})


@report_bp.route('/<report_id>/agent-log/stream', methods=['GET'])
@handle_api_error
def stream_agent_log(report_id: str):
    """Get complete agent log at once."""
    logs = ReportManager.get_agent_log_stream(report_id)
    return jsonify({"success": True, "data": {"logs": logs, "count": len(logs)}})


@report_bp.route('/<report_id>/console-log', methods=['GET'])
@handle_api_error
def get_console_log(report_id: str):
    """Get console output log."""
    from_line = request.args.get('from_line', 0, type=int)
    log_data = ReportManager.get_console_log(report_id, from_line=from_line)
    return jsonify({"success": True, "data": log_data})


@report_bp.route('/<report_id>/console-log/stream', methods=['GET'])
@handle_api_error
def stream_console_log(report_id: str):
    """Get complete console log at once."""
    logs = ReportManager.get_console_log_stream(report_id)
    return jsonify({"success": True, "data": {"logs": logs, "count": len(logs)}})
