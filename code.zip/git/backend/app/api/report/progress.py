"""
Report progress and section endpoints.
"""

import os

from flask import request, jsonify

from . import report_bp
from ...services.report_agent import ReportManager, ReportStatus
from ...utils.logger import get_logger
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.report')


@report_bp.route('/<report_id>/progress', methods=['GET'])
@handle_api_error
def get_report_progress(report_id: str):
    """Get real-time report generation progress."""
    progress = ReportManager.get_progress(report_id)
    if not progress:
        return jsonify({"success": False, "error": t('api.reportProgressNotAvail', id=report_id)}), 404
    return jsonify({"success": True, "data": progress})


@report_bp.route('/<report_id>/sections', methods=['GET'])
@handle_api_error
def get_report_sections(report_id: str):
    """Get list of generated report sections."""
    sections = ReportManager.get_generated_sections(report_id)
    report = ReportManager.get_report(report_id)
    is_complete = report is not None and report.status == ReportStatus.COMPLETED

    return jsonify({
        "success": True,
        "data": {
            "report_id": report_id,
            "sections": sections,
            "total_sections": len(sections),
            "is_complete": is_complete,
        },
    })


@report_bp.route('/<report_id>/section/<int:section_index>', methods=['GET'])
@handle_api_error
def get_single_section(report_id: str, section_index: int):
    """Get a single report section."""
    section_path = ReportManager._get_section_path(report_id, section_index)

    if not os.path.exists(section_path):
        return jsonify({
            "success": False,
            "error": t('api.sectionNotFound', index=f"{section_index:02d}"),
        }), 404

    with open(section_path, 'r', encoding='utf-8') as fh:
        content = fh.read()

    return jsonify({
        "success": True,
        "data": {
            "filename": f"section_{section_index:02d}.md",
            "section_index": section_index,
            "content": content,
        },
    })
