"""
Report generation endpoint (async task).
"""

import threading
import uuid

from flask import request, jsonify

from . import report_bp
from ...services.report_agent import ReportAgent, ReportManager, ReportStatus
from ...services.simulation_manager import SimulationManager
from ...models.project import ProjectManager
from ...models.task import TaskManager, TaskStatus
from ...utils.logger import get_logger
from ...utils.locale import t, get_locale, set_locale
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.report')


@report_bp.route('/generate', methods=['POST'])
@handle_api_error
def generate_report():
    """Generate a simulation analysis report (async task)."""
    data = request.get_json() or {}

    simulation_id = data.get('simulation_id')
    if not simulation_id:
        return jsonify({"success": False, "error": t('api.requireSimulationId')}), 400

    force_regenerate = data.get('force_regenerate', False)

    manager = SimulationManager()
    state = manager.get_simulation(simulation_id)
    if not state:
        return jsonify({"success": False, "error": t('api.simulationNotFound', id=simulation_id)}), 404

    # Check for existing report
    if not force_regenerate:
        existing = ReportManager.get_report_by_simulation(simulation_id)
        if existing and existing.status == ReportStatus.COMPLETED:
            return jsonify({
                "success": True,
                "data": {
                    "simulation_id": simulation_id,
                    "report_id": existing.report_id,
                    "status": "completed",
                    "message": t('api.reportAlreadyExists'),
                    "already_generated": True,
                },
            })

    project = ProjectManager.get_project(state.project_id)
    if not project:
        return jsonify({"success": False, "error": t('api.projectNotFound', id=state.project_id)}), 404

    graph_id = state.graph_id or project.graph_id
    if not graph_id:
        return jsonify({"success": False, "error": t('api.missingGraphIdEnsure')}), 400

    simulation_requirement = project.simulation_requirement
    if not simulation_requirement:
        return jsonify({"success": False, "error": t('api.missingSimRequirement')}), 400

    report_id = f"report_{uuid.uuid4().hex[:12]}"

    task_manager = TaskManager()
    task_id = task_manager.create_task(
        task_type="report_generate",
        metadata={"simulation_id": simulation_id, "graph_id": graph_id, "report_id": report_id},
    )

    current_locale = get_locale()

    def run_generate():
        set_locale(current_locale)
        try:
            task_manager.update_task(
                task_id, status=TaskStatus.PROCESSING, progress=0,
                message=t('api.initReportAgent'),
            )

            agent = ReportAgent(
                graph_id=graph_id,
                simulation_id=simulation_id,
                simulation_requirement=simulation_requirement,
            )

            def progress_callback(stage, prog, message):
                task_manager.update_task(task_id, progress=prog, message=f"[{stage}] {message}")

            report = agent.generate_report(progress_callback=progress_callback, report_id=report_id)
            ReportManager.save_report(report)

            if report.status == ReportStatus.COMPLETED:
                task_manager.complete_task(task_id, result={
                    "report_id": report.report_id,
                    "simulation_id": simulation_id,
                    "status": "completed",
                })
            else:
                task_manager.fail_task(task_id, report.error or t('api.reportGenerateFailed'))

        except Exception as e:
            logger.error(f"Report generation failed: {e}")
            task_manager.fail_task(task_id, str(e))

    threading.Thread(target=run_generate, daemon=True).start()

    return jsonify({
        "success": True,
        "data": {
            "simulation_id": simulation_id,
            "report_id": report_id,
            "task_id": task_id,
            "status": "generating",
            "message": t('api.reportGenerateStarted'),
            "already_generated": False,
        },
    })


@report_bp.route('/generate/status', methods=['POST'])
@handle_api_error
def get_generate_status():
    """Query report generation task progress."""
    data = request.get_json() or {}
    task_id = data.get('task_id')
    simulation_id = data.get('simulation_id')

    if simulation_id:
        existing = ReportManager.get_report_by_simulation(simulation_id)
        if existing and existing.status == ReportStatus.COMPLETED:
            return jsonify({
                "success": True,
                "data": {
                    "simulation_id": simulation_id,
                    "report_id": existing.report_id,
                    "status": "completed",
                    "progress": 100,
                    "message": t('api.reportGenerated'),
                    "already_completed": True,
                },
            })

    if not task_id:
        return jsonify({"success": False, "error": t('api.requireTaskOrSimId')}), 400

    task_manager = TaskManager()
    task = task_manager.get_task(task_id)
    if not task:
        return jsonify({"success": False, "error": t('api.taskNotFound', id=task_id)}), 404

    return jsonify({"success": True, "data": task.to_dict()})
