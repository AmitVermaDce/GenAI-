"""
Report API package.

Splits the monolithic report route module into focused sub-modules.
"""

from flask import Blueprint

report_bp = Blueprint('report', __name__)

# Import route modules so their decorators register on the blueprint.
from . import generation   # noqa: E402, F401
from . import retrieval    # noqa: E402, F401
from . import chat         # noqa: E402, F401
from . import progress     # noqa: E402, F401
from . import logs         # noqa: E402, F401
from . import tools        # noqa: E402, F401
