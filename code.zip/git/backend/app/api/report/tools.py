"""
Report debug tool endpoints (graph search, statistics).
"""

from flask import request, jsonify

from . import report_bp
from ...utils.locale import t
from ...utils.logger import get_logger
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.report')


@report_bp.route('/tools/search', methods=['POST'])
@handle_api_error
def search_graph_tool():
    """Graph search tool API (debug)."""
    data = request.get_json() or {}
    graph_id = data.get('graph_id')
    query = data.get('query')
    limit = data.get('limit', 10)

    if not graph_id or not query:
        return jsonify({"success": False, "error": t('api.requireGraphIdAndQuery')}), 400

    from ...services.graph_tools import GraphToolsService

    tools = GraphToolsService()
    result = tools.search_graph(graph_id=graph_id, query=query, limit=limit)
    return jsonify({"success": True, "data": result.to_dict()})


@report_bp.route('/tools/statistics', methods=['POST'])
@handle_api_error
def get_graph_statistics_tool():
    """Graph statistics tool API (debug)."""
    data = request.get_json() or {}
    graph_id = data.get('graph_id')

    if not graph_id:
        return jsonify({"success": False, "error": t('api.requireGraphId')}), 400

    from ...services.graph_tools import GraphToolsService

    tools = GraphToolsService()
    result = tools.get_graph_statistics(graph_id)
    return jsonify({"success": True, "data": result})
