"""
Report retrieval, listing, download, and deletion endpoints.
"""

import os

from flask import request, jsonify, send_file

from . import report_bp
from ...services.report_agent import ReportManager, ReportStatus
from ...utils.logger import get_logger
from ...utils.locale import t
from ...middleware.error_handlers import handle_api_error

logger = get_logger('jarvis.api.report')


@report_bp.route('/<report_id>', methods=['GET'])
@handle_api_error
def get_report(report_id: str):
    """Get report details."""
    report = ReportManager.get_report(report_id)
    if not report:
        return jsonify({"success": False, "error": t('api.reportNotFound', id=report_id)}), 404
    return jsonify({"success": True, "data": report.to_dict()})


@report_bp.route('/by-simulation/<simulation_id>', methods=['GET'])
@handle_api_error
def get_report_by_simulation(simulation_id: str):
    """Get report by simulation ID."""
    report = ReportManager.get_report_by_simulation(simulation_id)
    if not report:
        return jsonify({
            "success": False,
            "error": t('api.noReportForSim', id=simulation_id),
            "has_report": False,
        }), 404
    return jsonify({"success": True, "data": report.to_dict(), "has_report": True})


@report_bp.route('/list', methods=['GET'])
@handle_api_error
def list_reports():
    """List all reports."""
    simulation_id = request.args.get('simulation_id')
    limit = request.args.get('limit', 50, type=int)
    reports = ReportManager.list_reports(simulation_id=simulation_id, limit=limit)
    return jsonify({
        "success": True,
        "data": [r.to_dict() for r in reports],
        "count": len(reports),
    })


@report_bp.route('/<report_id>/download', methods=['GET'])
@handle_api_error
def download_report(report_id: str):
    """Download report as Markdown."""
    report = ReportManager.get_report(report_id)
    if not report:
        return jsonify({"success": False, "error": t('api.reportNotFound', id=report_id)}), 404

    md_path = ReportManager._get_report_markdown_path(report_id)

    if not os.path.exists(md_path):
        import tempfile
        with tempfile.NamedTemporaryFile(mode='w', suffix='.md', delete=False) as fh:
            fh.write(report.markdown_content)
            temp_path = fh.name
        return send_file(temp_path, as_attachment=True, download_name=f"{report_id}.md")

    return send_file(md_path, as_attachment=True, download_name=f"{report_id}.md")


@report_bp.route('/<report_id>', methods=['DELETE'])
@handle_api_error
def delete_report(report_id: str):
    """Delete a report."""
    success = ReportManager.delete_report(report_id)
    if not success:
        return jsonify({"success": False, "error": t('api.reportNotFound', id=report_id)}), 404
    return jsonify({"success": True, "message": t('api.reportDeleted', id=report_id)})


@report_bp.route('/check/<simulation_id>', methods=['GET'])
@handle_api_error
def check_report_status(simulation_id: str):
    """Check whether a simulation has a completed report."""
    report = ReportManager.get_report_by_simulation(simulation_id)
    has_report = report is not None
    return jsonify({
        "success": True,
        "data": {
            "simulation_id": simulation_id,
            "has_report": has_report,
            "report_status": report.status.value if report else None,
            "report_id": report.report_id if report else None,
            "interview_unlocked": has_report and report.status == ReportStatus.COMPLETED,
        },
    })
