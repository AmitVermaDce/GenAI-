"""
Graph Provider Abstraction Layer.

Replaces direct Zep Cloud SDK dependency with a pluggable graph backend.
Currently supports: Graphiti (graphiti-core + Neo4j).

Usage:
    from app.services.graph_provider import get_graph_client, GraphClient
    client = get_graph_client()
"""

from .base import (
    GraphClient,
    GraphNode,
    GraphEdge,
    EpisodeData,
    SearchResult as GraphSearchResult,
    OntologyConfig,
)
from .factory import get_graph_client

__all__ = [
    "GraphClient",
    "GraphNode",
    "GraphEdge",
    "EpisodeData",
    "GraphSearchResult",
    "OntologyConfig",
    "get_graph_client",
]
