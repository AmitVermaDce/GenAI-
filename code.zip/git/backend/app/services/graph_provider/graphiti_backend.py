"""
Graphiti-core + Neo4j backend implementation of GraphClient.

Uses the ``graphiti-core`` library to interact with a local Neo4j instance
for knowledge-graph operations (entity extraction, episodic memory, search).

Required environment variables (loaded via Config):
    NEO4J_URI          – bolt://localhost:7687
    NEO4J_USER         – neo4j
    NEO4J_PASSWORD     – <password>
    GRAPHITI_GROUP_ID  – default group / namespace (optional, defaults to "jarvis")
"""

from __future__ import annotations

import asyncio
import logging
import time
import uuid
from functools import wraps
from typing import Any, Callable, Dict, List, Optional, TypeVar

from .base import (
    EpisodeData,
    GraphClient,
    GraphEdge,
    GraphNode,
    OntologyConfig,
    SearchResult,
)

logger = logging.getLogger(__name__)

T = TypeVar("T")

_MAX_RETRIES = 3
_RETRY_DELAY = 2  # seconds


def _run_async(coro):
    """Run an async coroutine from synchronous code."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None

    if loop and loop.is_running():
        # We're inside an existing event loop (e.g. Jupyter, some ASGI frameworks).
        # Create a new thread to run the coroutine.
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
            return pool.submit(asyncio.run, coro).result()
    else:
        return asyncio.run(coro)


def _with_retry(func: Callable[..., T], operation: str, max_retries: int = _MAX_RETRIES) -> T:
    """Call *func* with exponential-backoff retry on transient errors."""
    last_exc: Exception | None = None
    delay = _RETRY_DELAY
    for attempt in range(1, max_retries + 1):
        try:
            return func()
        except (ConnectionError, TimeoutError, OSError) as exc:
            last_exc = exc
            if attempt < max_retries:
                logger.warning(
                    "%s attempt %d/%d failed: %s – retrying in %ds",
                    operation, attempt, max_retries, str(exc)[:120], delay,
                )
                time.sleep(delay)
                delay *= 2
            else:
                logger.error("%s failed after %d attempts: %s", operation, max_retries, exc)
    raise last_exc  # type: ignore[misc]


class GraphitiBackend(GraphClient):
    """
    GraphClient implementation backed by ``graphiti-core`` + Neo4j.

    All heavy lifting (entity extraction, community detection, search) is
    delegated to Graphiti.  We map Graphiti's async API to the synchronous
    interface expected by the rest of the Jarvis codebase.
    """

    def __init__(
        self,
        neo4j_uri: str,
        neo4j_user: str,
        neo4j_password: str,
        group_id: str = "jarvis",
        llm_api_key: str = "",
        llm_base_url: str = "",
        llm_model: str = "",
    ):
        try:
            from graphiti_core import Graphiti
            from graphiti_core.llm_client import OpenAIClient
        except ImportError as exc:
            raise ImportError(
                "graphiti-core is required for the Graphiti backend. "
                "Install it with: pip install graphiti-core"
            ) from exc

        self._group_id = group_id

        # Build an LLM client for Graphiti's entity extraction pipeline
        llm_client = None
        if llm_api_key:
            from openai import AsyncOpenAI
            llm_client = OpenAIClient(
                client=AsyncOpenAI(api_key=llm_api_key, base_url=llm_base_url or None),
                model=llm_model or "gpt-4o-mini",
            )

        self._graphiti = Graphiti(
            neo4j_uri,
            neo4j_user,
            neo4j_password,
            llm_client=llm_client,
        )

        # Keep a mapping of logical graph_id → group_id used in Graphiti
        # (Graphiti uses group_id for namespacing rather than separate graph objects)
        self._graph_groups: Dict[str, str] = {}

        logger.info("GraphitiBackend initialised (neo4j=%s, group=%s)", neo4j_uri, group_id)

    # -- lifecycle ----------------------------------------------------------

    def close(self) -> None:
        try:
            _run_async(self._graphiti.close())
        except Exception as exc:
            logger.warning("Error closing Graphiti: %s", exc)

    # -- graph CRUD ---------------------------------------------------------

    def create_graph(self, graph_id: str, name: str, description: str = "") -> str:
        group = f"{self._group_id}_{graph_id}"
        self._graph_groups[graph_id] = group
        # Graphiti doesn't have an explicit "create graph" – the group namespace
        # is implicitly created when episodes are added.  We build indices.
        try:
            _run_async(self._graphiti.build_indices_and_constraints())
        except Exception as exc:
            logger.warning("Index build note: %s", exc)
        logger.info("Logical graph '%s' mapped to group '%s'", graph_id, group)
        return graph_id

    def delete_graph(self, graph_id: str) -> None:
        """Delete all data for a graph (by group_id)."""
        group = self._graph_groups.pop(graph_id, f"{self._group_id}_{graph_id}")
        try:
            from graphiti_core.utils.maintenance.graph_data_operations import clear_data
            _run_async(clear_data(self._graphiti.driver, group_id=group))
            logger.info("Deleted graph data for group '%s'", group)
        except Exception as exc:
            logger.error("Failed to delete graph '%s': %s", graph_id, exc)
            raise

    # -- ontology -----------------------------------------------------------

    def set_ontology(self, graph_id: str, ontology: OntologyConfig) -> None:
        """
        Store ontology metadata.  Graphiti extracts entities automatically via
        its LLM pipeline so an explicit ontology is *guidance* rather than a
        hard schema.  We persist it as graph-level metadata.
        """
        # Graphiti doesn't enforce a fixed ontology the way Zep does.
        # We store the ontology definition as a special episode so the LLM
        # extraction pipeline is aware of the desired entity/edge types.
        ontology_text = self._ontology_to_guidance_text(ontology)
        if ontology_text:
            self.add_text(graph_id, ontology_text)
        logger.info("Ontology guidance ingested for graph '%s'", graph_id)

    @staticmethod
    def _ontology_to_guidance_text(ontology: OntologyConfig) -> str:
        """Convert an OntologyConfig into a natural-language description that
        guides Graphiti's entity extraction."""
        parts = ["[Ontology Definition]\n"]
        for et in ontology.entity_types:
            desc = et.get("description", "")
            attrs = ", ".join(
                a.get("name", a) if isinstance(a, dict) else str(a)
                for a in et.get("attributes", [])
            )
            parts.append(f"Entity type '{et['name']}': {desc}. Attributes: {attrs}")
        for ed in ontology.edge_types:
            desc = ed.get("description", "")
            parts.append(f"Edge type '{ed['name']}': {desc}")
        return "\n".join(parts)

    # -- episode ingestion --------------------------------------------------

    def add_episodes(self, graph_id: str, episodes: List[EpisodeData]) -> List[str]:
        group = self._graph_groups.get(graph_id, f"{self._group_id}_{graph_id}")
        episode_ids: List[str] = []
        for ep in episodes:
            ep_id = str(uuid.uuid4())
            try:
                def _add(text=ep.data, gid=group, eid=ep_id):
                    from graphiti_core.nodes import EpisodicNode
                    return _run_async(
                        self._graphiti.add_episode(
                            name=f"episode_{eid[:8]}",
                            episode_body=text,
                            source_description="jarvis_ingestion",
                            group_id=gid,
                        )
                    )
                _with_retry(_add, f"add_episode({ep_id[:8]})")
                episode_ids.append(ep_id)
            except Exception as exc:
                logger.error("Failed to add episode: %s", exc)
        return episode_ids

    def add_text(self, graph_id: str, text: str) -> None:
        self.add_episodes(graph_id, [EpisodeData(data=text)])

    def get_episode(self, episode_id: str) -> Optional[Dict[str, Any]]:
        # Graphiti doesn't expose a direct get-episode-by-id in the same way.
        # We return a synthetic "processed" marker.
        return {"uuid": episode_id, "processed": True}

    # -- node operations ----------------------------------------------------

    def get_nodes(self, graph_id: str, limit: int = 100, cursor: Optional[str] = None) -> List[GraphNode]:
        group = self._graph_groups.get(graph_id, f"{self._group_id}_{graph_id}")
        try:
            from graphiti_core.search.search_utils import get_entity_nodes
            raw = _run_async(get_entity_nodes(self._graphiti.driver, group_id=group))
            nodes = []
            for n in raw:
                nodes.append(GraphNode(
                    uuid=str(getattr(n, 'uuid', '')),
                    name=getattr(n, 'name', ''),
                    labels=getattr(n, 'labels', []) or [getattr(n, 'label', 'Entity')],
                    summary=getattr(n, 'summary', '') or '',
                    attributes=getattr(n, 'attributes', {}) or {},
                    created_at=str(getattr(n, 'created_at', '')) if getattr(n, 'created_at', None) else None,
                ))
            return nodes[:limit]
        except Exception as exc:
            logger.error("get_nodes failed: %s", exc)
            return []

    def get_node(self, node_uuid: str) -> Optional[GraphNode]:
        try:
            from graphiti_core.nodes import EntityNode
            raw = _run_async(EntityNode.get_by_uuid(self._graphiti.driver, node_uuid))
            if not raw:
                return None
            return GraphNode(
                uuid=str(getattr(raw, 'uuid', '')),
                name=getattr(raw, 'name', ''),
                labels=getattr(raw, 'labels', []) or [getattr(raw, 'label', 'Entity')],
                summary=getattr(raw, 'summary', '') or '',
                attributes=getattr(raw, 'attributes', {}) or {},
            )
        except Exception as exc:
            logger.warning("get_node(%s) failed: %s", node_uuid[:8], exc)
            return None

    def get_node_edges(self, node_uuid: str) -> List[GraphEdge]:
        try:
            from graphiti_core.edges import EntityEdge
            raw = _run_async(EntityEdge.get_by_node_uuid(self._graphiti.driver, node_uuid))
            return [self._raw_edge_to_graph_edge(e) for e in (raw or [])]
        except Exception as exc:
            logger.warning("get_node_edges(%s) failed: %s", node_uuid[:8], exc)
            return []

    # -- edge operations ----------------------------------------------------

    def get_edges(self, graph_id: str, limit: int = 100, cursor: Optional[str] = None) -> List[GraphEdge]:
        group = self._graph_groups.get(graph_id, f"{self._group_id}_{graph_id}")
        try:
            from graphiti_core.search.search_utils import get_entity_edges
            raw = _run_async(get_entity_edges(self._graphiti.driver, group_id=group))
            edges = [self._raw_edge_to_graph_edge(e) for e in (raw or [])]
            return edges[:limit]
        except Exception as exc:
            logger.error("get_edges failed: %s", exc)
            return []

    # -- search -------------------------------------------------------------

    def search(
        self,
        graph_id: str,
        query: str,
        limit: int = 10,
        scope: str = "edges",
        reranker: Optional[str] = None,
    ) -> SearchResult:
        group = self._graph_groups.get(graph_id, f"{self._group_id}_{graph_id}")
        try:
            raw = _run_async(
                self._graphiti.search(
                    query=query,
                    group_ids=[group],
                    num_results=limit,
                )
            )
            facts = []
            edges = []
            nodes = []
            for item in (raw or []):
                fact = getattr(item, 'fact', '') or getattr(item, 'content', '')
                if fact:
                    facts.append(fact)
                # Edges returned from search
                if hasattr(item, 'source_node_uuid'):
                    edges.append({
                        "uuid": str(getattr(item, 'uuid', '')),
                        "name": getattr(item, 'name', ''),
                        "fact": fact,
                        "source_node_uuid": getattr(item, 'source_node_uuid', ''),
                        "target_node_uuid": getattr(item, 'target_node_uuid', ''),
                    })
                elif hasattr(item, 'labels'):
                    nodes.append({
                        "uuid": str(getattr(item, 'uuid', '')),
                        "name": getattr(item, 'name', ''),
                        "labels": getattr(item, 'labels', []),
                        "summary": getattr(item, 'summary', ''),
                    })
            return SearchResult(
                facts=facts,
                edges=edges,
                nodes=nodes,
                query=query,
                total_count=len(facts),
            )
        except Exception as exc:
            logger.error("search failed for graph '%s': %s", graph_id, exc)
            return SearchResult(query=query)

    # -- helpers ------------------------------------------------------------

    @staticmethod
    def _raw_edge_to_graph_edge(e: Any) -> GraphEdge:
        return GraphEdge(
            uuid=str(getattr(e, 'uuid', '')),
            name=getattr(e, 'name', '') or '',
            fact=getattr(e, 'fact', '') or getattr(e, 'content', '') or '',
            source_node_uuid=str(getattr(e, 'source_node_uuid', '')),
            target_node_uuid=str(getattr(e, 'target_node_uuid', '')),
            attributes=getattr(e, 'attributes', {}) or {},
            created_at=str(getattr(e, 'created_at', '')) if getattr(e, 'created_at', None) else None,
            valid_at=str(getattr(e, 'valid_at', '')) if getattr(e, 'valid_at', None) else None,
            invalid_at=str(getattr(e, 'invalid_at', '')) if getattr(e, 'invalid_at', None) else None,
            expired_at=str(getattr(e, 'expired_at', '')) if getattr(e, 'expired_at', None) else None,
        )

    # -- bulk overrides for efficiency --------------------------------------

    def get_all_nodes(self, graph_id: str, max_items: int = 2000) -> List[GraphNode]:
        """Override: fetch all at once from Neo4j (more efficient than pagination)."""
        return self.get_nodes(graph_id, limit=max_items)

    def get_all_edges(self, graph_id: str) -> List[GraphEdge]:
        """Override: fetch all at once from Neo4j."""
        return self.get_edges(graph_id, limit=10000)
