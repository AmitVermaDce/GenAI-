"""
Abstract base classes for the graph provider layer.

Every concrete backend (Graphiti, future alternatives) must implement GraphClient.
Data classes (GraphNode, GraphEdge, EpisodeData, etc.) are backend-agnostic.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional


# ---------------------------------------------------------------------------
# Data transfer objects – thin, backend-agnostic
# ---------------------------------------------------------------------------

@dataclass
class GraphNode:
    """A node / entity in the knowledge graph."""
    uuid: str
    name: str
    labels: List[str] = field(default_factory=list)
    summary: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None


@dataclass
class GraphEdge:
    """An edge / relationship in the knowledge graph."""
    uuid: str
    name: str
    fact: str = ""
    source_node_uuid: str = ""
    target_node_uuid: str = ""
    attributes: Dict[str, Any] = field(default_factory=dict)
    created_at: Optional[str] = None
    valid_at: Optional[str] = None
    invalid_at: Optional[str] = None
    expired_at: Optional[str] = None
    episodes: List[str] = field(default_factory=list)

    @property
    def is_expired(self) -> bool:
        return self.expired_at is not None

    @property
    def is_invalid(self) -> bool:
        return self.invalid_at is not None


@dataclass
class EpisodeData:
    """A chunk of text to be ingested into the graph."""
    data: str
    type: str = "text"  # "text" | "json" | ...


@dataclass
class SearchResult:
    """Result of a graph semantic / hybrid search."""
    facts: List[str] = field(default_factory=list)
    edges: List[Dict[str, Any]] = field(default_factory=list)
    nodes: List[Dict[str, Any]] = field(default_factory=list)
    query: str = ""
    total_count: int = 0


@dataclass
class OntologyConfig:
    """Backend-agnostic ontology definition (entity types + edge types)."""
    entity_types: List[Dict[str, Any]] = field(default_factory=list)
    edge_types: List[Dict[str, Any]] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Compatibility shims – drop-in for zep_cloud ontology models
# ---------------------------------------------------------------------------

class EntityText:
    """Shim replacing ``zep_cloud.EntityText``."""
    pass


class EntityModel:
    """Shim replacing ``zep_cloud.external_clients.ontology.EntityModel``."""
    pass


class EdgeModel:
    """Shim replacing ``zep_cloud.external_clients.ontology.EdgeModel``."""
    pass


class EntityEdgeSourceTarget:
    """Shim replacing ``zep_cloud.EntityEdgeSourceTarget``."""
    def __init__(self, source: str = "Entity", target: str = "Entity"):
        self.source = source
        self.target = target


# ---------------------------------------------------------------------------
# Abstract client interface
# ---------------------------------------------------------------------------

class GraphClient(abc.ABC):
    """
    Abstract graph backend client.

    Concrete implementations must handle connection management, retries,
    pagination, etc. internally.
    """

    # -- lifecycle ----------------------------------------------------------

    @abc.abstractmethod
    def close(self) -> None:
        """Release resources / connections."""

    # -- graph CRUD ---------------------------------------------------------

    @abc.abstractmethod
    def create_graph(self, graph_id: str, name: str, description: str = "") -> str:
        """Create a new graph container. Returns the graph_id."""

    @abc.abstractmethod
    def delete_graph(self, graph_id: str) -> None:
        """Delete an entire graph."""

    # -- ontology -----------------------------------------------------------

    @abc.abstractmethod
    def set_ontology(self, graph_id: str, ontology: OntologyConfig) -> None:
        """Apply an ontology schema to a graph."""

    # -- episode ingestion --------------------------------------------------

    @abc.abstractmethod
    def add_episodes(self, graph_id: str, episodes: List[EpisodeData]) -> List[str]:
        """
        Ingest a batch of episodes. Returns a list of episode UUIDs / IDs.
        """

    @abc.abstractmethod
    def add_text(self, graph_id: str, text: str) -> None:
        """Ingest a single text blob (convenience wrapper)."""

    @abc.abstractmethod
    def get_episode(self, episode_id: str) -> Optional[Dict[str, Any]]:
        """Retrieve an episode by its ID. Returns None if not found."""

    # -- node operations ----------------------------------------------------

    @abc.abstractmethod
    def get_nodes(self, graph_id: str, limit: int = 100, cursor: Optional[str] = None) -> List[GraphNode]:
        """Paginated node retrieval."""

    @abc.abstractmethod
    def get_node(self, node_uuid: str) -> Optional[GraphNode]:
        """Get a single node by UUID."""

    @abc.abstractmethod
    def get_node_edges(self, node_uuid: str) -> List[GraphEdge]:
        """Get edges connected to a specific node."""

    # -- edge operations ----------------------------------------------------

    @abc.abstractmethod
    def get_edges(self, graph_id: str, limit: int = 100, cursor: Optional[str] = None) -> List[GraphEdge]:
        """Paginated edge retrieval."""

    # -- search -------------------------------------------------------------

    @abc.abstractmethod
    def search(
        self,
        graph_id: str,
        query: str,
        limit: int = 10,
        scope: str = "edges",
        reranker: Optional[str] = None,
    ) -> SearchResult:
        """Semantic / hybrid search across the graph."""

    # -- bulk helpers (default implementations) -----------------------------

    def get_all_nodes(self, graph_id: str, max_items: int = 2000) -> List[GraphNode]:
        """Fetch all nodes via pagination. Override for optimised backends."""
        all_nodes: List[GraphNode] = []
        cursor: Optional[str] = None
        page_size = 100
        while True:
            batch = self.get_nodes(graph_id, limit=page_size, cursor=cursor)
            if not batch:
                break
            all_nodes.extend(batch)
            if len(all_nodes) >= max_items:
                return all_nodes[:max_items]
            if len(batch) < page_size:
                break
            cursor = batch[-1].uuid
        return all_nodes

    def get_all_edges(self, graph_id: str) -> List[GraphEdge]:
        """Fetch all edges via pagination. Override for optimised backends."""
        all_edges: List[GraphEdge] = []
        cursor: Optional[str] = None
        page_size = 100
        while True:
            batch = self.get_edges(graph_id, limit=page_size, cursor=cursor)
            if not batch:
                break
            all_edges.extend(batch)
            if len(batch) < page_size:
                break
            cursor = batch[-1].uuid
        return all_edges
