"""
Factory for creating the configured GraphClient instance.

Reads ``GRAPH_PROVIDER`` from Config to decide which backend to instantiate.
Supported values: ``"graphiti"`` (default).
"""

from __future__ import annotations

import logging
import threading
from typing import Optional

from .base import GraphClient

logger = logging.getLogger(__name__)

_instance: Optional[GraphClient] = None
_lock = threading.Lock()


def get_graph_client(force_new: bool = False) -> GraphClient:
    """
    Return a singleton ``GraphClient`` instance.

    Thread-safe.  Set *force_new* to discard the cached instance.
    """
    global _instance
    if _instance is not None and not force_new:
        return _instance

    with _lock:
        if _instance is not None and not force_new:
            return _instance

        from ...config import Config

        provider = getattr(Config, "GRAPH_PROVIDER", "graphiti").lower()

        if provider == "graphiti":
            from .graphiti_backend import GraphitiBackend

            _instance = GraphitiBackend(
                neo4j_uri=getattr(Config, "NEO4J_URI", "bolt://localhost:7687"),
                neo4j_user=getattr(Config, "NEO4J_USER", "neo4j"),
                neo4j_password=getattr(Config, "NEO4J_PASSWORD", ""),
                group_id=getattr(Config, "GRAPHITI_GROUP_ID", "jarvis"),
                llm_api_key=Config.LLM_API_KEY,
                llm_base_url=Config.LLM_BASE_URL,
                llm_model=Config.LLM_MODEL_NAME,
            )
        else:
            raise ValueError(
                f"Unknown GRAPH_PROVIDER '{provider}'. Supported: 'graphiti'"
            )

        logger.info("Graph provider initialised: %s", provider)
        return _instance
