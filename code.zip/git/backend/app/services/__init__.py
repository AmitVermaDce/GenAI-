"""
Service layer module.

Uses lazy imports to avoid circular dependencies and speed up startup.
Import specific services directly from their modules::

    from app.services.graph_builder import GraphBuilderService
    from app.services.simulation_manager import SimulationManager
"""


def __getattr__(name):
    """Lazy-load service classes on first access."""
    _mapping = {
        "get_graph_client": ".graph_provider",
        "GraphClient": ".graph_provider",
        "OntologyGenerator": ".ontology_generator",
        "GraphBuilderService": ".graph_builder",
        "TextProcessor": ".text_processor",
        "EntityReader": ".entity_reader",
        "ZepEntityReader": ".entity_reader",
        "EntityNode": ".entity_reader",
        "FilteredEntities": ".entity_reader",
        "OasisProfileGenerator": ".oasis_profile_generator",
        "OasisAgentProfile": ".oasis_profile_generator",
        "SimulationManager": ".simulation_manager",
        "SimulationState": ".simulation_manager",
        "SimulationStatus": ".simulation_manager",
        "SimulationConfigGenerator": ".simulation_config_generator",
        "SimulationParameters": ".simulation_config_generator",
        "AgentActivityConfig": ".simulation_config_generator",
        "TimeSimulationConfig": ".simulation_config_generator",
        "EventConfig": ".simulation_config_generator",
        "PlatformConfig": ".simulation_config_generator",
        "SimulationRunner": ".simulation_runner",
        "SimulationRunState": ".simulation_runner",
        "RunnerStatus": ".simulation_runner",
        "AgentAction": ".simulation_runner",
        "RoundSummary": ".simulation_runner",
        "GraphMemoryUpdater": ".graph_memory_updater",
        "GraphMemoryManager": ".graph_memory_updater",
        "ZepGraphMemoryUpdater": ".graph_memory_updater",
        "ZepGraphMemoryManager": ".graph_memory_updater",
        "AgentActivity": ".graph_memory_updater",
        "GraphToolsService": ".graph_tools",
        "ZepToolsService": ".graph_tools",
        "SimulationIPCClient": ".simulation_ipc",
        "SimulationIPCServer": ".simulation_ipc",
        "IPCCommand": ".simulation_ipc",
        "IPCResponse": ".simulation_ipc",
        "CommandType": ".simulation_ipc",
        "CommandStatus": ".simulation_ipc",
    }

    if name in _mapping:
        import importlib
        module = importlib.import_module(_mapping[name], __package__)
        return getattr(module, name)

    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


__all__ = [
    'get_graph_client',
    'GraphClient',
    'OntologyGenerator',
    'GraphBuilderService',
    'TextProcessor',
    'EntityReader',
    'EntityNode',
    'FilteredEntities',
    'OasisProfileGenerator',
    'OasisAgentProfile',
    'SimulationManager',
    'SimulationState',
    'SimulationStatus',
    'SimulationConfigGenerator',
    'SimulationParameters',
    'AgentActivityConfig',
    'TimeSimulationConfig',
    'EventConfig',
    'PlatformConfig',
    'SimulationRunner',
    'SimulationRunState',
    'RunnerStatus',
    'AgentAction',
    'RoundSummary',
    'GraphMemoryUpdater',
    'GraphMemoryManager',
    'GraphToolsService',
    'AgentActivity',
    'SimulationIPCClient',
    'SimulationIPCServer',
    'IPCCommand',
    'IPCResponse',
    'CommandType',
    'CommandStatus',
]

