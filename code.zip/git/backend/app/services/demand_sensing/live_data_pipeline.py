"""
Live Data Pipeline for Demand Sensing
Background worker that periodically fetches demand signals from external sources,
ingests them into the knowledge graph, and triggers forecast adjustments.
"""

import logging
import threading
import time
from typing import Dict, Any, List, Optional

logger = logging.getLogger(__name__)

from ...config import Config


class LiveDataPipeline:
    """
    Background pipeline that:
    1. Periodically polls external signal sources (POS, weather, inventory, etc.)
    2. Ingests signals into the Zep knowledge graph via Graphify
    3. Triggers forecast adjustments when deviations are detected
    """

    def __init__(self):
        self._app = None
        self._running = False
        self._thread: Optional[threading.Thread] = None
        self._poll_interval_hours = 1
        self._lock = threading.Lock()

    def init_app(self, app):
        """Initialize with Flask app context."""
        self._app = app
        self._poll_interval_hours = Config.LIVE_POLL_INTERVAL

        if Config.DEMAND_SENSING_ENABLED:
            self.start()
            logger.info(
                f"LiveDataPipeline initialized (poll interval: {self._poll_interval_hours}h)"
            )
        else:
            logger.info("Demand sensing disabled — LiveDataPipeline not started")

    # ── Public API ─────────────────────────────────────────────────────

    def start(self):
        """Start the background polling thread."""
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._poll_loop, daemon=True)
        self._thread.start()
        logger.info("LiveDataPipeline background thread started")

    def stop(self):
        """Stop the background polling thread."""
        self._running = False
        if self._thread:
            self._thread.join(timeout=5)
        logger.info("LiveDataPipeline stopped")

    def fetch_demand_signals(
        self,
        project_id: str,
        sku: str = None,
        location: str = None,
        sources: List[str] = None,
    ) -> Dict[str, List[Dict[str, Any]]]:
        """
        Fetch demand signals from all registered handlers.

        Returns:
            Dict mapping source_name → list of signal dicts
        """
        try:
            from .signal_handlers import SignalHandlerRegistry

            return SignalHandlerRegistry.fetch_all_signals(
                sku=sku, location=location, sources=sources
            )
        except Exception as e:
            logger.error(f"Error fetching demand signals: {e}")
            return {}

    def ingest_demand_signals_to_graph(
        self,
        project_id: str,
        signals: Dict[str, List[Dict[str, Any]]],
    ) -> int:
        """
        Convert signals into graph facts and add them to the project's
        knowledge graph via the Graphify module.

        Returns:
            Number of facts added
        """
        try:
            from .graphify import create_graphifier

            graphifier = create_graphifier(project_id)

            all_facts = []
            for signal_type, signal_list in signals.items():
                for sig in signal_list:
                    facts = graphifier.graphify_signal(signal_type, sig)
                    all_facts.extend(facts)

            if all_facts:
                added = graphifier.add_facts_to_graph(all_facts)
                logger.info(
                    f"Ingested {added} graph facts for project {project_id}"
                )
                return added
            return 0
        except Exception as e:
            logger.error(f"Error ingesting signals to graph: {e}")
            return 0

    def process_demand_signals_for_forecasting(
        self,
        project_id: str,
        signals: Dict[str, List[Dict[str, Any]]],
    ) -> Dict[str, Any]:
        """
        Process fetched signals: extract POS observations, check for
        deviations, and trigger adjustments.

        Returns:
            Summary dict with observations_added, adjustments_triggered, etc.
        """
        results = {
            "observations_added": 0,
            "adjustments_triggered": 0,
            "errors": [],
        }

        try:
            from .forecast_model import DemandForecastModel
            from .adjuster import DemandAdjuster

            model = DemandForecastModel(project_id)
            adjuster = DemandAdjuster(project_id)

            # Process POS signals as demand observations
            pos_signals = signals.get("pos", [])
            for sig in pos_signals:
                sku = sig.get("sku")
                location = sig.get("location")
                date_str = sig.get("date")
                quantity = sig.get("quantity") or sig.get("demand")

                if not all([sku, location, date_str, quantity]):
                    continue

                try:
                    model.add_demand_observation(
                        sku, location, date_str, float(quantity), source="pos_pipeline"
                    )
                    results["observations_added"] += 1

                    # Check for deviations
                    adjustment = adjuster.check_and_adjust(
                        sku, location, float(quantity), date_str, signals
                    )
                    if adjustment:
                        results["adjustments_triggered"] += 1
                except Exception as inner_e:
                    results["errors"].append(str(inner_e))

        except Exception as e:
            logger.error(f"Error processing signals for forecasting: {e}")
            results["errors"].append(str(e))

        return results

    # ── Background loop ────────────────────────────────────────────────

    def _poll_loop(self):
        """Background thread that periodically fetches and processes signals."""
        interval_seconds = self._poll_interval_hours * 3600

        while self._running:
            try:
                # Interruptible sleep: check _running every second
                for _ in range(int(interval_seconds)):
                    if not self._running:
                        return
                    time.sleep(1)

                if not self._running:
                    return

                logger.info("LiveDataPipeline: starting periodic signal fetch")
                # In the background we don't have a specific project, so
                # this is a no-op unless projects register themselves.
                # Individual projects trigger fetches via the API.
            except Exception as e:
                logger.error(f"LiveDataPipeline poll error: {e}")


# Module-level singleton
live_data_pipeline = LiveDataPipeline()
