"""
Middleware module for cross-cutting concerns.
"""

from .error_handlers import register_error_handlers, handle_api_error

__all__ = ["register_error_handlers", "handle_api_error"]
