"""
Centralized error handling for API endpoints.

Provides a decorator and utilities to replace the repetitive
try/except + traceback.format_exc() pattern found in every route handler.
"""

import traceback
import logging
from functools import wraps
from flask import jsonify, current_app

logger = logging.getLogger(__name__)


def handle_api_error(func):
    """
    Decorator for API route handlers that catches exceptions and returns
    a standardised JSON error response.

    In debug mode the full traceback is included; in production it is stripped
    by the after_request handler registered in the app factory.

    Usage::

        @bp.route('/example')
        @handle_api_error
        def my_endpoint():
            ...
    """

    @wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ValueError as exc:
            logger.warning(f"Validation error in {func.__name__}: {exc}")
            return jsonify({
                "success": False,
                "error": str(exc),
            }), 400
        except FileNotFoundError as exc:
            logger.warning(f"Not found in {func.__name__}: {exc}")
            return jsonify({
                "success": False,
                "error": str(exc),
            }), 404
        except TimeoutError as exc:
            logger.error(f"Timeout in {func.__name__}: {exc}")
            return jsonify({
                "success": False,
                "error": str(exc),
            }), 504
        except Exception as exc:
            logger.error(f"Unhandled error in {func.__name__}: {exc}")
            logger.debug(traceback.format_exc())
            payload = {
                "success": False,
                "error": str(exc),
            }
            # Include traceback only in debug mode (stripped in prod by after_request)
            if current_app.debug:
                payload["traceback"] = traceback.format_exc()
            return jsonify(payload), 500

    return wrapper


def register_error_handlers(app):
    """
    Register application-level error handlers for common HTTP errors.
    Called from the app factory.
    """

    @app.errorhandler(400)
    def bad_request(error):
        return jsonify({
            "success": False,
            "error": str(error.description) if hasattr(error, "description") else "Bad request",
        }), 400

    @app.errorhandler(404)
    def not_found(error):
        return jsonify({
            "success": False,
            "error": str(error.description) if hasattr(error, "description") else "Not found",
        }), 404

    @app.errorhandler(405)
    def method_not_allowed(error):
        return jsonify({
            "success": False,
            "error": "Method not allowed",
        }), 405

    @app.errorhandler(500)
    def internal_error(error):
        return jsonify({
            "success": False,
            "error": "Internal server error",
        }), 500
