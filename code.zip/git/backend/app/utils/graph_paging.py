"""Graph pagination utilities.

Legacy module – previously contained Zep Cloud pagination logic.
Now delegates to the graph provider abstraction layer.

These functions are kept for backward compatibility with existing callers
that import ``fetch_all_nodes`` / ``fetch_all_edges`` directly.
"""

from __future__ import annotations

import logging
from typing import Any

from ..services.graph_provider import get_graph_client

logger = logging.getLogger('jarvis.graph_paging')

_DEFAULT_PAGE_SIZE = 100
_MAX_NODES = 2000


def fetch_all_nodes(
    client: Any = None,
    graph_id: str = "",
    page_size: int = _DEFAULT_PAGE_SIZE,
    max_items: int = _MAX_NODES,
    **kwargs: Any,
) -> list[Any]:
    """Fetch all nodes for a graph via the graph provider.

    The *client* parameter is accepted for backward compatibility but ignored;
    the singleton graph provider client is used instead.
    """
    gc = get_graph_client()
    return gc.get_all_nodes(graph_id, max_items=max_items)


def fetch_all_edges(
    client: Any = None,
    graph_id: str = "",
    **kwargs: Any,
) -> list[Any]:
    """Fetch all edges for a graph via the graph provider.

    The *client* parameter is accepted for backward compatibility but ignored.
    """
    gc = get_graph_client()
    return gc.get_all_edges(graph_id)
