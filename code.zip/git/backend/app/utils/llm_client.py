"""
LLM client module
 using OpenAI-compatible formatcall
"""

import json
import re
import time
import logging
from typing import Optional, Dict, Any, List
from openai import OpenAI, APITimeoutError, APIConnectionError, RateLimitError

from ..config import Config

logger = logging.getLogger(__name__)

MAX_RETRIES = 3
RETRY_DELAY = 2  # seconds


class LLMClient:
    """LLM Client"""
    
    def __init__(
        self,
        api_key: Optional[str] = None,
        base_url: Optional[str] = None,
        model: Optional[str] = None
    ):
        self.api_key = api_key or Config.LLM_API_KEY
        self.base_url = base_url or Config.LLM_BASE_URL
        self.model = model or Config.LLM_MODEL_NAME
        
        # For Ollama/local LLMs, use a placeholder key
        if not self.api_key and self.base_url and 'localhost' in self.base_url:
            self.api_key = 'ollama'
        
        if not self.api_key:
            raise ValueError("LLM_API_KEY not configured")
        
        self.client = OpenAI(
            api_key=self.api_key,
            base_url=self.base_url
        )
    
    def chat(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.7,
        max_tokens: int = 4096,
        response_format: Optional[Dict] = None
    ) -> str:
        """
        Send a chat request
        
        Args:
            messages: message list
            temperature: temperature parameter
            max_tokens: maximum token count
            response_format: response format( for JSON mode)
            
        Returns:
             model response text
        """
        kwargs = {
            "model": self.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
        }
        
        if response_format:
            kwargs["response_format"] = response_format
        
        # Retry on transient errors (timeouts, connection issues, rate limits)
        last_error = None
        for attempt in range(1, MAX_RETRIES + 1):
            try:
                response = self.client.chat.completions.create(**kwargs)
                content = response.choices[0].message.content
                # Some models ( e.g. MiniMax M2.5) include <think> blocks — strip them
                content = re.sub(r'<think>[\s\S]*?</think>', '', content).strip()
                return content
            except (APITimeoutError, APIConnectionError) as e:
                last_error = e
                if attempt < MAX_RETRIES:
                    logger.warning(f"LLM call attempt {attempt}/{MAX_RETRIES} failed: {e}. Retrying in {RETRY_DELAY * attempt}s...")
                    time.sleep(RETRY_DELAY * attempt)
                else:
                    raise
            except RateLimitError as e:
                last_error = e
                if attempt < MAX_RETRIES:
                    wait = RETRY_DELAY * attempt * 2  # longer backoff for rate limits
                    logger.warning(f"Rate limited, retrying in {wait}s...")
                    time.sleep(wait)
                else:
                    raise
        raise last_error  # should not reach here
    
    def chat_json(
        self,
        messages: List[Dict[str, str]],
        temperature: float = 0.3,
        max_tokens: int = 4096
    ) -> Dict[str, Any]:
        """
        Send a chat request and return JSON
        
        Args:
            messages: message list
            temperature: temperature parameter
            max_tokens: maximum token count
            
        Returns:
            parse after JSONobject
        """
        response = self.chat(
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens,
            response_format={"type": "json_object"}
        )
        # cleanupmarkdown code block mark
        cleaned_response = response.strip()
        cleaned_response = re.sub(r'^```(?:json)?\s*\n?', '', cleaned_response, flags=re.IGNORECASE)
        cleaned_response = re.sub(r'\n?```\s*$', '', cleaned_response)
        cleaned_response = cleaned_response.strip()

        try:
            return json.loads(cleaned_response)
        except json.JSONDecodeError:
            raise ValueError(f"LLM return JSONformatinvalid: {cleaned_response}")

