/**
 * Demand Sensing API module
 * Wraps all /api/demand-sensing endpoints with the shared axios instance.
 */
import service from './index'

const BASE = '/api/demand-sensing'

// ── Dashboard & Trends ─────────────────────────────────────────────

export function getDashboard(projectId) {
  return service.get(`${BASE}/dashboard/${projectId}`)
}

export function getTrends(projectId, { sku, location, historyDays, forecastDays } = {}) {
  const params = {}
  if (sku) params.sku = sku
  if (location) params.location = location
  if (historyDays) params.history_days = historyDays
  if (forecastDays) params.forecast_days = forecastDays
  return service.get(`${BASE}/trends/${projectId}`, { params })
}

export function getSummary(projectId) {
  return service.get(`${BASE}/summary/${projectId}`)
}

// ── Forecasts ──────────────────────────────────────────────────────

export function createForecast({ projectId, sku, location, startDate, days = 14 }) {
  return service.post(`${BASE}/forecast`, {
    project_id: projectId,
    sku,
    location,
    start_date: startDate || new Date().toISOString().split('T')[0],
    days,
  })
}

export function getForecasts(projectId, { sku, location, limit } = {}) {
  const params = {}
  if (sku) params.sku = sku
  if (location) params.location = location
  if (limit) params.limit = limit
  return service.get(`${BASE}/forecast/${projectId}`, { params })
}

// ── Alerts ─────────────────────────────────────────────────────────

export function getAlerts(projectId, { sku, location, severity, acknowledged } = {}) {
  const params = { project_id: projectId }
  if (sku) params.sku = sku
  if (location) params.location = location
  if (severity) params.severity = severity
  if (acknowledged !== undefined) params.acknowledged = acknowledged
  return service.get(`${BASE}/alerts`, { params })
}

export function acknowledgeAlert(alertId, projectId) {
  return service.post(`${BASE}/alerts/${alertId}/acknowledge?project_id=${projectId}`)
}

// ── Adjustments ────────────────────────────────────────────────────

export function getAdjustments(projectId, { sku, location, limit } = {}) {
  const params = { project_id: projectId }
  if (sku) params.sku = sku
  if (location) params.location = location
  if (limit) params.limit = limit
  return service.get(`${BASE}/adjustments`, { params })
}

// ── Observations ───────────────────────────────────────────────────

export function addObservation({ projectId, sku, location, date, demand }) {
  return service.post(`${BASE}/observations`, {
    project_id: projectId, sku, location, date, demand,
  })
}

export function addBulkObservations(projectId, observations) {
  return service.post(`${BASE}/observations/bulk`, {
    project_id: projectId,
    observations,
  })
}

// ── Parallel Scenarios ─────────────────────────────────────────────

export function runParallelScenarios({ projectId, scenarios, startDate, days = 14 }) {
  return service.post(`${BASE}/scenarios/run`, {
    project_id: projectId,
    scenarios,
    start_date: startDate || new Date().toISOString().split('T')[0],
    days,
  })
}

// ── Signals ────────────────────────────────────────────────────────

export function fetchSignals({ projectId, sku, location, sources } = {}) {
  return service.post(`${BASE}/signals/fetch`, {
    project_id: projectId, sku, location, sources,
  })
}

export function ingestSignals(projectId, signals) {
  return service.post(`${BASE}/signals/ingest`, {
    project_id: projectId, signals,
  })
}

// ── Health ─────────────────────────────────────────────────────────

export function healthCheck() {
  return service.get(`${BASE}/health`)
}
