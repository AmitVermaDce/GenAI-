/**
 * Frontend Component Organisation
 *
 * components/
 * ├── common/          — Shared / layout components
 * │   ├── GraphPanel.vue
 * │   ├── LanguageSwitcher.vue
 * │
 * ├── workflow/         — Multi-step workflow components
 * │   ├── Step1GraphBuild.vue
 * │   ├── Step2EnvSetup.vue
 * │   ├── Step3Simulation.vue
 * │   ├── Step4Report.vue
 * │   ├── Step5Interaction.vue
 * │
 * └── home/             — Home-page specific
 *     ├── HistoryDatabase.vue
 *     ├── ScenarioPresets.vue
 *
 * Note: Components are kept in the flat components/ directory for
 * backward-compatibility with existing view imports.
 * This index provides convenient grouped re-exports.
 */

// Common
export { default as GraphPanel } from './GraphPanel.vue'
export { default as LanguageSwitcher } from './LanguageSwitcher.vue'

// Workflow Steps
export { default as Step1GraphBuild } from './Step1GraphBuild.vue'
export { default as Step2EnvSetup } from './Step2EnvSetup.vue'
export { default as Step3Simulation } from './Step3Simulation.vue'
export { default as Step4Report } from './Step4Report.vue'
export { default as Step5Interaction } from './Step5Interaction.vue'

// Home
export { default as HistoryDatabase } from './HistoryDatabase.vue'
export { default as ScenarioPresets } from './ScenarioPresets.vue'
