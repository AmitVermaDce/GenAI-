<template>
  <div class="demand-sensing-view">
    <!-- ─── Top Header ─── -->
    <header class="ds-header">
      <div class="ds-header-left">
        <button class="btn-back" @click="$router.push('/')">← {{ t('demandSensing.backHome') }}</button>
        <h1>{{ t('demandSensing.title') }}</h1>
        <span class="project-tag">{{ projectId }}</span>
      </div>
      <div class="ds-header-right">
        <button class="btn-icon" @click="refreshAll" :disabled="globalLoading">
          <span :class="{ spinning: globalLoading }">⟳</span> {{ t('demandSensing.refresh') }}
        </button>
      </div>
    </header>

    <!-- ─── KPI Cards ─── -->
    <section class="kpi-row">
      <div class="kpi-card">
        <div class="kpi-value">{{ dashboard.tracked_combos ?? '—' }}</div>
        <div class="kpi-label">{{ t('demandSensing.trackedCombos') }}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-value">{{ dashboard.total_forecasts ?? '—' }}</div>
        <div class="kpi-label">{{ t('demandSensing.totalForecasts') }}</div>
      </div>
      <div class="kpi-card accent">
        <div class="kpi-value">{{ dashboard.unacknowledged_alerts ?? '—' }}</div>
        <div class="kpi-label">{{ t('demandSensing.openAlerts') }}</div>
      </div>
      <div class="kpi-card">
        <div class="kpi-value">{{ (dashboard.recent_adjustments || []).length }}</div>
        <div class="kpi-label">{{ t('demandSensing.recentAdj') }}</div>
      </div>
    </section>

    <!-- ─── Tabs ─── -->
    <nav class="ds-tabs">
      <button v-for="tab in tabs" :key="tab.id"
        :class="['tab-btn', { active: activeTab === tab.id }]"
        @click="activeTab = tab.id">
        {{ tab.label }}
      </button>
    </nav>

    <!-- ════════════════ TAB: Trends ════════════════ -->
    <section v-if="activeTab === 'trends'" class="tab-content">
      <div class="trend-controls">
        <input v-model="trendFilters.sku" :placeholder="t('demandSensing.skuPlaceholder')" class="input" />
        <input v-model="trendFilters.location" :placeholder="t('demandSensing.locationPlaceholder')" class="input" />
        <button class="btn-primary" @click="loadTrends">{{ t('demandSensing.loadTrends') }}</button>
      </div>

      <div v-if="trendLoading" class="loading-bar"><div class="loading-fill"></div></div>

      <div v-if="trendData" class="chart-container">
        <svg ref="trendChart"></svg>
      </div>

      <div v-if="!trendData && !trendLoading" class="empty-state">
        <p>{{ t('demandSensing.trendEmpty') }}</p>
      </div>
    </section>

    <!-- ════════════════ TAB: Parallel Scenarios ════════════════ -->
    <section v-if="activeTab === 'scenarios'" class="tab-content">
      <div class="scenario-builder">
        <h3>{{ t('demandSensing.buildScenarios') }}</h3>
        <div v-for="(sc, idx) in scenarioInputs" :key="idx" class="scenario-row">
          <span class="scenario-num">#{{ idx + 1 }}</span>
          <input v-model="sc.sku" placeholder="SKU" class="input sm" />
          <input v-model="sc.location" placeholder="Location" class="input sm" />
          <input v-model="sc.label" placeholder="Label" class="input" />
          <button class="btn-danger-sm" @click="removeScenario(idx)" v-if="scenarioInputs.length > 1">✕</button>
        </div>
        <div class="scenario-actions">
          <button class="btn-secondary" @click="addScenario">+ {{ t('demandSensing.addScenario') }}</button>
          <button class="btn-primary" @click="runScenarios" :disabled="scenarioRunning">
            {{ scenarioRunning ? t('demandSensing.running') : t('demandSensing.runAll') }}
          </button>
        </div>
      </div>

      <div v-if="scenarioRunning" class="loading-bar"><div class="loading-fill"></div></div>

      <!-- Scenario comparison chart -->
      <div v-if="scenarioResults.length" class="chart-container">
        <svg ref="scenarioChart"></svg>
      </div>

      <!-- Scenario cards -->
      <div v-if="scenarioResults.length" class="scenario-cards">
        <div v-for="sr in scenarioResults" :key="sr.label" class="scenario-card"
          :class="{ 'has-error': sr.status === 'error' }">
          <div class="sc-header">
            <strong>{{ sr.label }}</strong>
            <span class="sc-badge" v-if="sr.status === 'error'">Error</span>
            <span class="sc-badge ok" v-else>{{ sr.forecasts?.length ?? 0 }} pts</span>
          </div>
          <div v-if="sr.status === 'error'" class="sc-error">{{ sr.error }}</div>
          <div v-else class="sc-stats">
            <span>History: {{ sr.history?.length ?? 0 }}</span>
            <span>Alerts: {{ sr.alerts_count ?? 0 }}</span>
            <span>Adj: {{ sr.adjustments_count ?? 0 }}</span>
          </div>
        </div>
      </div>
    </section>

    <!-- ════════════════ TAB: Forecasts ════════════════ -->
    <section v-if="activeTab === 'forecasts'" class="tab-content">
      <div class="trend-controls">
        <input v-model="filters.sku" :placeholder="t('demandSensing.skuPlaceholder')" class="input" />
        <input v-model="filters.location" :placeholder="t('demandSensing.locationPlaceholder')" class="input" />
        <button class="btn-primary" @click="generateForecast">{{ t('demandSensing.generateForecast') }}</button>
      </div>

      <div v-if="forecastLoading" class="loading-bar"><div class="loading-fill"></div></div>

      <div v-if="forecasts.length > 0" class="forecasts-table-wrapper">
        <table class="forecasts-table">
          <thead>
            <tr>
              <th>{{ t('demandSensing.date') }}</th>
              <th>{{ t('demandSensing.sku') }}</th>
              <th>{{ t('demandSensing.location') }}</th>
              <th>{{ t('demandSensing.predictedDemand') }}</th>
              <th>{{ t('demandSensing.confidence') }}</th>
              <th>Range</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="f in forecasts" :key="`${f.sku}-${f.location}-${f.date}`">
              <td>{{ f.date }}</td>
              <td>{{ f.sku }}</td>
              <td>{{ f.location }}</td>
              <td class="demand-value">{{ f.predicted_demand?.toFixed(1) }}</td>
              <td>
                <div class="confidence-bar">
                  <div class="confidence-fill" :style="{ width: `${f.confidence * 100}%` }"
                    :class="getConfidenceClass(f.confidence)"></div>
                  <span>{{ (f.confidence * 100).toFixed(0) }}%</span>
                </div>
              </td>
              <td class="range-cell">{{ f.lower_bound?.toFixed(0) }} – {{ f.upper_bound?.toFixed(0) }}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <div v-else-if="!forecastLoading" class="empty-state">
        <p>{{ t('demandSensing.noForecasts') }}</p>
      </div>
    </section>

    <!-- ════════════════ TAB: Alerts ════════════════ -->
    <section v-if="activeTab === 'alerts'" class="tab-content">
      <div class="alerts-list" v-if="alerts.length">
        <div v-for="alert in alerts" :key="alert.id"
          :class="['alert-item', `severity-${alert.severity}`]">
          <div class="alert-header">
            <span :class="['badge', alert.severity]">{{ alert.severity.toUpperCase() }}</span>
            <span class="alert-type">{{ alert.alert_type }}</span>
            <span class="alert-date">{{ formatDate(alert.created_at) }}</span>
          </div>
          <p class="alert-message">{{ alert.message }}</p>
          <div class="alert-details">
            <span>SKU: {{ alert.sku }}</span>
            <span>Location: {{ alert.location }}</span>
            <span>Deviation: {{ alert.deviation_percent?.toFixed(1) }}%</span>
          </div>
          <button v-if="!alert.acknowledged" @click="doAcknowledge(alert.id)" class="btn-acknowledge">
            {{ t('demandSensing.acknowledge') }}
          </button>
        </div>
      </div>
      <div v-else class="empty-state">
        <p>{{ t('demandSensing.noAlerts') }}</p>
      </div>
    </section>

    <!-- ════════════════ TAB: Add Data ════════════════ -->
    <section v-if="activeTab === 'addData'" class="tab-content">
      <div class="data-section">
        <h3>{{ t('demandSensing.addObservation') }}</h3>
        <div class="form-row">
          <input v-model="observation.sku" :placeholder="t('demandSensing.sku')" class="input" />
          <input v-model="observation.location" :placeholder="t('demandSensing.location')" class="input" />
          <input v-model="observation.date" type="date" class="input" />
          <input v-model="observation.demand" type="number" :placeholder="t('demandSensing.demand')" class="input" />
          <button @click="addObs" class="btn-primary">{{ t('demandSensing.add') }}</button>
        </div>
      </div>

      <div class="data-section">
        <h3>{{ t('demandSensing.bulkUpload') }}</h3>
        <textarea v-model="bulkText" class="textarea"
          :placeholder="t('demandSensing.bulkPlaceholder')"></textarea>
        <button @click="addBulk" class="btn-primary">{{ t('demandSensing.uploadBulk') }}</button>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, reactive, computed, onMounted, nextTick } from 'vue'
import { useI18n } from 'vue-i18n'
import * as d3 from 'd3'
import {
  getDashboard, getTrends, createForecast, getAlerts,
  acknowledgeAlert, addObservation as apiAddObs,
  addBulkObservations as apiBulkObs, runParallelScenarios
} from '../api/demandSensing'

const { t } = useI18n()

const props = defineProps({
  projectId: { type: String, required: true }
})

// ── State ──────────────────────────────────────────────────────────

const globalLoading = ref(false)
const activeTab = ref('trends')
const dashboard = ref({})

const tabs = computed(() => [
  { id: 'trends', label: t('demandSensing.tabTrends') },
  { id: 'scenarios', label: t('demandSensing.tabScenarios') },
  { id: 'forecasts', label: t('demandSensing.tabForecasts') },
  { id: 'alerts', label: `${t('demandSensing.tabAlerts')} (${dashboard.value.unacknowledged_alerts ?? 0})` },
  { id: 'addData', label: t('demandSensing.tabAddData') },
])

// Trends
const trendFilters = reactive({ sku: '', location: '' })
const trendLoading = ref(false)
const trendData = ref(null)
const trendChart = ref(null)

// Forecasts
const filters = reactive({ sku: '', location: '' })
const forecastLoading = ref(false)
const forecasts = ref([])

// Alerts
const alerts = ref([])

// Scenarios
const scenarioInputs = ref([
  { sku: '', location: '', label: 'Scenario 1' },
  { sku: '', location: '', label: 'Scenario 2' },
])
const scenarioRunning = ref(false)
const scenarioResults = ref([])
const scenarioChart = ref(null)

// Add Data
const observation = reactive({ sku: '', location: '', date: new Date().toISOString().split('T')[0], demand: '' })
const bulkText = ref('')

// ── Lifecycle ──────────────────────────────────────────────────────

onMounted(async () => {
  await refreshAll()
})

// ── Data Loading ───────────────────────────────────────────────────

async function refreshAll() {
  globalLoading.value = true
  try {
    const res = await getDashboard(props.projectId)
    if (res) {
      dashboard.value = res.data ?? res
    }
    try {
      const alertRes = await getAlerts(props.projectId, { acknowledged: false })
      const ad = alertRes?.data ?? alertRes
      if (ad?.alerts) alerts.value = ad.alerts
    } catch { /* ignore */ }
  } catch (e) {
    console.error('Dashboard load failed:', e)
  } finally {
    globalLoading.value = false
  }
}

async function loadTrends() {
  trendLoading.value = true
  try {
    const res = await getTrends(props.projectId, {
      sku: trendFilters.sku || undefined,
      location: trendFilters.location || undefined,
    })
    const data = res?.data ?? res
    if (data) {
      trendData.value = data
      await nextTick()
      renderTrendChart()
    }
  } catch (e) {
    console.error('Trends load failed:', e)
  } finally {
    trendLoading.value = false
  }
}

async function generateForecast() {
  if (!filters.sku || !filters.location) return window.alert(t('demandSensing.fillFilters'))
  forecastLoading.value = true
  try {
    const res = await createForecast({ projectId: props.projectId, sku: filters.sku, location: filters.location })
    const data = res?.data ?? res
    if (data?.forecasts) forecasts.value = data.forecasts
  } catch (e) {
    console.error('Forecast failed:', e)
  } finally {
    forecastLoading.value = false
  }
}

async function doAcknowledge(alertId) {
  try {
    await acknowledgeAlert(alertId, props.projectId)
    alerts.value = alerts.value.filter(a => a.id !== alertId)
    if (dashboard.value.unacknowledged_alerts > 0) dashboard.value.unacknowledged_alerts--
  } catch (e) {
    console.error('Acknowledge failed:', e)
  }
}

async function addObs() {
  if (!observation.sku || !observation.location || !observation.demand) {
    return window.alert(t('demandSensing.fillAllFields'))
  }
  try {
    await apiAddObs({
      projectId: props.projectId, sku: observation.sku,
      location: observation.location, date: observation.date,
      demand: parseFloat(observation.demand),
    })
    observation.demand = ''
    window.alert(t('demandSensing.observationAdded'))
  } catch (e) {
    console.error('Add observation failed:', e)
  }
}

async function addBulk() {
  if (!bulkText.value.trim()) return
  const lines = bulkText.value.trim().split('\n')
  const observations = []
  for (const line of lines) {
    const parts = line.split(',').map(s => s.trim())
    if (parts.length >= 4) {
      observations.push({ sku: parts[0], location: parts[1], date: parts[2], demand: parseFloat(parts[3]) })
    }
  }
  if (!observations.length) return window.alert('No valid rows found')
  try {
    await apiBulkObs(props.projectId, observations)
    bulkText.value = ''
    window.alert(`Added ${observations.length} observations`)
  } catch (e) {
    console.error('Bulk add failed:', e)
  }
}

// ── Parallel Scenarios ─────────────────────────────────────────────

function addScenario() {
  scenarioInputs.value.push({ sku: '', location: '', label: `Scenario ${scenarioInputs.value.length + 1}` })
}
function removeScenario(idx) {
  scenarioInputs.value.splice(idx, 1)
}

async function runScenarios() {
  const valid = scenarioInputs.value.filter(s => s.sku && s.location)
  if (!valid.length) return window.alert('Fill at least one scenario with SKU and Location')
  scenarioRunning.value = true
  scenarioResults.value = []
  try {
    const res = await runParallelScenarios({ projectId: props.projectId, scenarios: valid })
    const data = res?.data ?? res
    if (data?.scenarios) {
      scenarioResults.value = data.scenarios
      await nextTick()
      renderScenarioChart()
    }
  } catch (e) {
    console.error('Scenario run failed:', e)
  } finally {
    scenarioRunning.value = false
  }
}

// ── D3 Charts ──────────────────────────────────────────────────────

function renderTrendChart() {
  if (!trendChart.value || !trendData.value) return
  const svg = d3.select(trendChart.value)
  svg.selectAll('*').remove()

  const margin = { top: 20, right: 30, bottom: 40, left: 60 }
  const width = Math.min(900, window.innerWidth - 100)
  const height = 360
  const innerW = width - margin.left - margin.right
  const innerH = height - margin.top - margin.bottom

  svg.attr('width', width).attr('height', height)
  const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`)

  const parseDate = d3.timeParse('%Y-%m-%d')
  const history = (trendData.value.history || []).map(d => ({ ...d, date: parseDate(d.date) })).filter(d => d.date)
  const fc = (trendData.value.forecasts || []).map(d => ({ ...d, date: parseDate(d.date) })).filter(d => d.date)

  const allDates = [...history.map(d => d.date), ...fc.map(d => d.date)]
  const allValues = [...history.map(d => d.demand), ...fc.map(d => d.demand), ...fc.map(d => d.upper || d.demand)]
  if (!allDates.length) return

  const x = d3.scaleTime().domain(d3.extent(allDates)).range([0, innerW])
  const y = d3.scaleLinear().domain([0, d3.max(allValues) * 1.15]).nice().range([innerH, 0])

  g.append('g').attr('transform', `translate(0,${innerH})`).call(d3.axisBottom(x).ticks(8)).selectAll('text').attr('fill', '#666')
  g.append('g').call(d3.axisLeft(y).ticks(6)).selectAll('text').attr('fill', '#666')
  g.append('g').call(d3.axisLeft(y).ticks(6).tickSize(-innerW).tickFormat('')).selectAll('line').attr('stroke', '#eee')

  // Confidence band
  if (fc.length > 1) {
    const area = d3.area().x(d => x(d.date)).y0(d => y(d.lower || d.demand * 0.8)).y1(d => y(d.upper || d.demand * 1.2)).curve(d3.curveMonotoneX)
    g.append('path').datum(fc).attr('fill', 'rgba(33,150,243,0.12)').attr('d', area)
  }

  // History line + dots
  if (history.length > 1) {
    g.append('path').datum(history).attr('fill', 'none').attr('stroke', '#333').attr('stroke-width', 2)
      .attr('d', d3.line().x(d => x(d.date)).y(d => y(d.demand)).curve(d3.curveMonotoneX))
  }
  g.selectAll('.dh').data(history).join('circle').attr('cx', d => x(d.date)).attr('cy', d => y(d.demand)).attr('r', 3).attr('fill', '#333')

  // Forecast line + dots
  if (fc.length > 1) {
    g.append('path').datum(fc).attr('fill', 'none').attr('stroke', '#2196f3').attr('stroke-width', 2).attr('stroke-dasharray', '6,3')
      .attr('d', d3.line().x(d => x(d.date)).y(d => y(d.demand)).curve(d3.curveMonotoneX))
  }
  g.selectAll('.df').data(fc).join('circle').attr('cx', d => x(d.date)).attr('cy', d => y(d.demand)).attr('r', 3).attr('fill', '#2196f3')

  // Adjustment markers
  const adjData = (trendData.value.adjustments || []).map(d => ({ ...d, date: parseDate(d.date) })).filter(d => d.date)
  g.selectAll('.am').data(adjData).join('polygon')
    .attr('points', d => { const cx = x(d.date), cy = y(d.adjusted); return `${cx},${cy - 8} ${cx - 6},${cy + 4} ${cx + 6},${cy + 4}` })
    .attr('fill', '#ff9800')

  // Legend
  const lg = g.append('g').attr('transform', `translate(${innerW - 200}, 0)`)
  lg.append('line').attr('x1', 0).attr('x2', 20).attr('y1', 0).attr('y2', 0).attr('stroke', '#333').attr('stroke-width', 2)
  lg.append('text').attr('x', 24).attr('y', 4).text('Actual').attr('fill', '#333').attr('font-size', 12)
  lg.append('line').attr('x1', 0).attr('x2', 20).attr('y1', 18).attr('y2', 18).attr('stroke', '#2196f3').attr('stroke-width', 2).attr('stroke-dasharray', '6,3')
  lg.append('text').attr('x', 24).attr('y', 22).text('Forecast').attr('fill', '#2196f3').attr('font-size', 12)
}

function renderScenarioChart() {
  if (!scenarioChart.value || !scenarioResults.value.length) return
  const svg = d3.select(scenarioChart.value)
  svg.selectAll('*').remove()

  const margin = { top: 20, right: 120, bottom: 40, left: 60 }
  const width = Math.min(900, window.innerWidth - 100)
  const height = 360
  const innerW = width - margin.left - margin.right
  const innerH = height - margin.top - margin.bottom

  svg.attr('width', width).attr('height', height)
  const g = svg.append('g').attr('transform', `translate(${margin.left},${margin.top})`)

  const parseDate = d3.timeParse('%Y-%m-%d')
  const colors = d3.scaleOrdinal(d3.schemeTableau10)

  const validSc = scenarioResults.value.filter(s => s.status === 'ok' && s.forecasts?.length)
  if (!validSc.length) return

  let allDates = [], allValues = []
  const series = validSc.map((sc, i) => {
    const pts = sc.forecasts.map(f => ({ date: parseDate(f.date), demand: f.predicted_demand })).filter(d => d.date)
    allDates.push(...pts.map(d => d.date))
    allValues.push(...pts.map(d => d.demand))
    return { label: sc.label, color: colors(i), points: pts }
  })

  const x = d3.scaleTime().domain(d3.extent(allDates)).range([0, innerW])
  const y = d3.scaleLinear().domain([0, d3.max(allValues) * 1.15]).nice().range([innerH, 0])

  g.append('g').attr('transform', `translate(0,${innerH})`).call(d3.axisBottom(x).ticks(8))
  g.append('g').call(d3.axisLeft(y).ticks(6))
  g.append('g').call(d3.axisLeft(y).ticks(6).tickSize(-innerW).tickFormat('')).selectAll('line').attr('stroke', '#eee')

  const line = d3.line().x(d => x(d.date)).y(d => y(d.demand)).curve(d3.curveMonotoneX)
  series.forEach(s => {
    g.append('path').datum(s.points).attr('fill', 'none').attr('stroke', s.color).attr('stroke-width', 2).attr('d', line)
    g.selectAll(null).data(s.points).join('circle').attr('cx', d => x(d.date)).attr('cy', d => y(d.demand)).attr('r', 3).attr('fill', s.color)
  })

  const lg = g.append('g').attr('transform', `translate(${innerW + 10}, 0)`)
  series.forEach((s, i) => {
    const row = lg.append('g').attr('transform', `translate(0, ${i * 20})`)
    row.append('rect').attr('width', 12).attr('height', 12).attr('fill', s.color)
    row.append('text').attr('x', 16).attr('y', 10).text(s.label).attr('font-size', 11).attr('fill', '#333')
  })
}

// ── Helpers ────────────────────────────────────────────────────────

function formatDate(d) { return d ? new Date(d).toLocaleString() : '' }
function getConfidenceClass(c) { return c >= 0.8 ? 'high' : c >= 0.5 ? 'medium' : 'low' }
</script>

<style scoped>
.demand-sensing-view { padding: 24px 32px; max-width: 1100px; margin: 0 auto; font-family: 'JetBrains Mono', 'Space Grotesk', monospace; }
.ds-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 24px; }
.ds-header-left { display: flex; align-items: center; gap: 16px; }
.ds-header-left h1 { font-size: 22px; font-weight: 700; }
.project-tag { background: #f0f0f0; padding: 2px 10px; border-radius: 4px; font-size: 12px; color: #666; }
.btn-back { background: none; border: 1px solid #ddd; border-radius: 4px; padding: 6px 12px; cursor: pointer; font-size: 13px; }
.btn-icon { background: #111; color: #fff; border: none; border-radius: 6px; padding: 8px 16px; cursor: pointer; font-size: 13px; display: flex; align-items: center; gap: 6px; }
.spinning { display: inline-block; animation: spin 1s linear infinite; }
@keyframes spin { to { transform: rotate(360deg); } }
.kpi-row { display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 24px; }
.kpi-card { background: #fff; border: 1px solid #eee; border-radius: 8px; padding: 20px; text-align: center; }
.kpi-card.accent { border-color: #f44336; }
.kpi-value { font-size: 28px; font-weight: 700; }
.kpi-card.accent .kpi-value { color: #f44336; }
.kpi-label { font-size: 12px; color: #888; margin-top: 4px; text-transform: uppercase; letter-spacing: 0.5px; }
.ds-tabs { display: flex; gap: 4px; border-bottom: 2px solid #eee; margin-bottom: 24px; }
.tab-btn { background: none; border: none; padding: 10px 18px; cursor: pointer; font-size: 14px; font-weight: 500; color: #888; border-bottom: 2px solid transparent; margin-bottom: -2px; transition: all 0.2s; }
.tab-btn.active { color: #111; border-bottom-color: #111; }
.tab-content { min-height: 400px; }
.trend-controls { display: flex; gap: 12px; margin-bottom: 16px; flex-wrap: wrap; }
.input { padding: 8px 12px; border: 1px solid #ddd; border-radius: 6px; font-size: 14px; font-family: inherit; }
.input.sm { max-width: 140px; }
.textarea { width: 100%; min-height: 120px; padding: 12px; border: 1px solid #ddd; border-radius: 6px; font-family: monospace; font-size: 13px; margin-bottom: 12px; resize: vertical; }
.btn-primary { background: #111; color: #fff; border: none; border-radius: 6px; padding: 8px 20px; cursor: pointer; font-size: 14px; }
.btn-primary:disabled { opacity: 0.5; cursor: not-allowed; }
.btn-secondary { background: #fff; color: #111; border: 1px solid #111; border-radius: 6px; padding: 8px 16px; cursor: pointer; font-size: 13px; }
.btn-danger-sm { background: #f44336; color: #fff; border: none; border-radius: 4px; width: 28px; height: 28px; cursor: pointer; font-size: 14px; }
.loading-bar { height: 3px; background: #eee; border-radius: 2px; overflow: hidden; margin-bottom: 20px; }
.loading-fill { height: 100%; width: 30%; background: #111; border-radius: 2px; animation: slide 1.2s ease-in-out infinite; }
@keyframes slide { 0% { margin-left: 0; } 50% { margin-left: 70%; } 100% { margin-left: 0; } }
.chart-container { background: #fff; border: 1px solid #eee; border-radius: 8px; padding: 20px; margin-bottom: 20px; overflow-x: auto; }
.empty-state { text-align: center; padding: 60px 20px; color: #999; }
.scenario-builder { background: #fafafa; border: 1px solid #eee; border-radius: 8px; padding: 20px; margin-bottom: 20px; }
.scenario-builder h3 { margin-bottom: 12px; font-size: 15px; }
.scenario-row { display: flex; gap: 8px; align-items: center; margin-bottom: 8px; }
.scenario-num { font-weight: 700; font-size: 13px; color: #888; min-width: 24px; }
.scenario-actions { display: flex; gap: 12px; margin-top: 12px; }
.scenario-cards { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 12px; }
.scenario-card { background: #fff; border: 1px solid #eee; border-radius: 8px; padding: 16px; }
.scenario-card.has-error { border-color: #f44336; }
.sc-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px; }
.sc-badge { font-size: 11px; padding: 2px 8px; border-radius: 4px; background: #eee; }
.sc-badge.ok { background: #e8f5e9; color: #2e7d32; }
.sc-error { color: #f44336; font-size: 13px; }
.sc-stats { display: flex; gap: 16px; font-size: 12px; color: #666; }
.forecasts-table-wrapper { overflow-x: auto; }
.forecasts-table { width: 100%; border-collapse: collapse; font-size: 14px; }
.forecasts-table th, .forecasts-table td { padding: 10px 14px; text-align: left; border-bottom: 1px solid #f0f0f0; }
.forecasts-table th { background: #fafafa; font-weight: 600; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px; color: #888; }
.demand-value { font-weight: 700; color: #2196f3; }
.range-cell { font-size: 12px; color: #999; }
.confidence-bar { display: flex; align-items: center; gap: 6px; }
.confidence-fill { height: 6px; border-radius: 3px; min-width: 4px; transition: width 0.3s; }
.confidence-fill.high { background: #4caf50; }
.confidence-fill.medium { background: #ff9800; }
.confidence-fill.low { background: #f44336; }
.alerts-list { display: flex; flex-direction: column; gap: 12px; }
.alert-item { padding: 16px; border-radius: 8px; border-left: 4px solid; background: #fff; }
.alert-item.severity-info { border-color: #2196f3; background: #f5f9ff; }
.alert-item.severity-warning { border-color: #ff9800; background: #fff8f0; }
.alert-item.severity-critical { border-color: #f44336; background: #fff5f5; }
.alert-header { display: flex; gap: 12px; align-items: center; margin-bottom: 6px; }
.badge { padding: 2px 8px; border-radius: 4px; font-size: 11px; font-weight: 700; color: white; }
.badge.info { background: #2196f3; }
.badge.warning { background: #ff9800; }
.badge.critical { background: #f44336; }
.alert-type { font-size: 12px; color: #666; }
.alert-date { font-size: 12px; color: #999; margin-left: auto; }
.alert-message { font-weight: 500; margin: 6px 0; }
.alert-details { display: flex; gap: 16px; font-size: 12px; color: #666; }
.btn-acknowledge { margin-top: 8px; padding: 6px 14px; background: #4caf50; color: white; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
.data-section { background: #fff; border: 1px solid #eee; border-radius: 8px; padding: 20px; margin-bottom: 16px; }
.data-section h3 { margin-bottom: 12px; font-size: 15px; }
.form-row { display: flex; gap: 10px; flex-wrap: wrap; }
.form-row .input { flex: 1; min-width: 130px; }
</style>